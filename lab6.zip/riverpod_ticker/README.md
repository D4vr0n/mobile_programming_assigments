# Riverpod Ticker

Lab 6: a live price ticker that shows every `AsyncValue` state (loading, data, error and refresh) with Dart 3 pattern matching on Riverpod providers.

## Features

- Simulated feed that sends BTC, ETH and SOL prices twice a second
- `StreamProvider` with `autoDispose`
- Loading spinner on the first load only
- On error: old prices stay on screen (dimmed) with a banner and a Retry button
- Thin progress bar while refreshing, pull-to-refresh on the list
- Bug button in the AppBar makes the feed fail after 5 batches, and the check button makes it stable again
- 6 tests (provider and widget tests)

## Project structure

```
lib/
  main.dart
  models/tick.dart
  services/tick_feed.dart
  providers/ticker_providers.dart
  widgets/tick_row.dart
  ticker_page.dart
test/
  ticker_providers_test.dart
  ticker_page_test.dart
NOTES.md
```

## Run

```bash
flutter create riverpod_ticker --empty
cd riverpod_ticker
flutter pub add flutter_riverpod
flutter pub add --dev flutter_test riverpod_test mocktail
```

Copy `lib/`, `test/` and `NOTES.md` into the project, then:

```bash
flutter analyze
flutter test
flutter run
```

Requires `flutter_riverpod` 3.x (the code imports `flutter_riverpod/legacy.dart` for `StateProvider`).

## Git tags (one per part)

The lab wants a commit and a tag at the end of each part. Example for Part 1:

```bash
git add .
git commit -m "Part 1: setup"
git tag p1-setup
git push && git push --tags
```

| Part | Tag |
|------|-----|
| 1 Setup | `p1-setup` |
| 2 Model and provider | `p2-provider` |
| 3 Ticker UI | `p3-ui` |
| 4 Resilience | `p4-resilience` |
| 5 Tests | `p5-tests` |

`parts/ticker_page_part3.txt` is the simple three-way-switch version of `ticker_page.dart` for the Part 3 commit. The file in `lib/` is the final Part 4 version.
