# Lab 6 Notes: Real-Time Ticker with AsyncValue

## Part 2: Model and stream provider

**Why is the feed behind its own `Provider` instead of being created inside `tickerProvider`?**
Because then it can be replaced. In tests I override `tickFeedProvider` with a feed that has one symbol or that fails after 1 batch. In the app, `failAfterProvider` changes it to show the error state. If `tickerProvider` created `TickFeed()` itself, I could not swap it without editing the code.

**What does `autoDispose` do when the user leaves the page mid-stream?**
When nobody is listening to the provider any more, Riverpod disposes it and cancels the stream subscription. The feed stops. When the user comes back, the provider starts again from scratch and shows the loading state.

**What `AsyncValue` does `tickerProvider` hold during the 800 ms delay, and what is `hasValue`?**
It holds `AsyncLoading`. `hasValue` is `false`, because no tick has arrived yet.

## Part 3: Ticker UI

**3.3 Break the switch on purpose**
I commented out the `AsyncLoading()` arm and ran `flutter analyze`. The analyzer reports a non-exhaustive switch error, in this form:

```
The type 'AsyncValue<List<Tick>>' is not exhaustively matched by the switch cases
since it doesn't match 'AsyncLoading<List<Tick>>()'.
Try adding a wildcard pattern, or cases that match 'AsyncLoading<List<Tick>>()'.
```

This is the guarantee I rely on: `AsyncValue` is sealed, so the compiler knows all three subtypes and tells me when I forget one.

**3.4 Pattern-match on content**
I added `AsyncData(value: [])` (empty list) and `AsyncData(value: [final only])` (one item) above the general `AsyncData(:final value)` arm.

**Why must these arms come before the general `AsyncData` arm?**
A switch checks arms from top to bottom and uses the first one that matches. The general `AsyncData(:final value)` matches every list, so if it was first, the empty and single-item arms would never run.

## Part 4: Errors, retry and keeping old data

**4.3 `refresh` vs `invalidate`**
I wrapped the list in a `RefreshIndicator`. Both ways kept the old rows on screen while reloading, because the new `AsyncLoading` or `AsyncData` copies the previous value. The thin progress bar appeared on top of the rows in both cases.

`ref.refresh(tickerProvider.future)` returns something awaitable because `refresh` rebuilds the provider right away and gives back the new result. For a stream provider the `.future` completes with the first new batch, so the pull-to-refresh spinner stays until new data arrives. `ref.invalidate` only marks the provider as out of date and returns nothing (`void`), so the spinner would end immediately unless I wrap it in an `async` function.

**4.4 Reconnect vs first load**
After a retry, the full-screen spinner does not appear if prices were shown before. The arm `AsyncValue(:final value?, isLoading: true)` sits above `AsyncLoading()`, so a loading state that still has old data shows the rows with a thin progress bar. Only a cold start, with no old value, reaches `AsyncLoading()`.

**Difference between `isRefreshing` and `isReloading`:** `isRefreshing` is true when the reload was started by `ref.refresh` or `ref.invalidate`, while `isReloading` is true when the provider rebuilt because something it watches changed (for example `failAfterProvider`), and in both cases the old value is still there.

## Part 5: Tests

I override `tickerProvider` (and `tickFeedProvider`) with hand-made streams, so there are no timers and no random numbers. `flutter test` runs 6 tests: 2 provider tests and 4 widget tests, including the error-after-data test with a `StreamController`.

---

## Checkpoint questions

**1. Which three subtypes make `AsyncValue` sealed, and what does the analyzer report when a `switch` expression misses one?**
`AsyncData`, `AsyncLoading` and `AsyncError`. If a switch misses one, the analyzer reports that the switch is not exhaustive and names the missing type (see 3.3 above). It is a compile-time error, not a runtime crash.

**2. When does `AsyncError.value` carry a non-null value, and when is it null?**
It is non-null when the provider had data before the error happened, because Riverpod keeps the previous value (for example, the feed sent ticks and then disconnected). It is null when the error came on the very first load, before any data.

**3. What is the difference between `ref.refresh(provider)`, `ref.refresh(provider.future)` and `ref.invalidate(provider)`?**
- `ref.refresh(provider)` rebuilds the provider immediately and returns the new `AsyncValue`.
- `ref.refresh(provider.future)` rebuilds it immediately and returns a `Future` that completes when the new value is ready. This is useful for `RefreshIndicator`.
- `ref.invalidate(provider)` only marks it as out of date, returns nothing, and it is rebuilt the next time it is needed (if someone is listening, soon after).

**4. Why do `AsyncValue(:final value?, isLoading: true)` and `AsyncError(:final error, :final value?)` need to sit above `AsyncData(:final value)`?**
Because arms are checked in order and the first match wins. A refresh can produce a value that is still marked as loading, and an error can still carry old data. The general `AsyncData(:final value)` arm would match and show plain rows, so the banner and the progress bar would never appear. Specific arms go above general ones.

**5. One reason to prefer `switch` over `.when(...)`, and one situation where `.when` is still convenient.**
A `switch` is exhaustive and checked by the compiler, and it can match on the content (empty list, error with old data) or combine conditions in one arm, which `.when` cannot do easily. `.when` is still convenient for a short, simple case where I only need three small callbacks and no extra conditions.
