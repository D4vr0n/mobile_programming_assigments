import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'models/tick.dart';
import 'providers/ticker_providers.dart';
import 'widgets/tick_row.dart';

class TickerPage extends ConsumerWidget {
  const TickerPage({super.key});

  /// The list of rows, wrapped in pull-to-refresh.
  Widget _rows(WidgetRef ref, List<Tick> ticks) {
    return RefreshIndicator(
      // refresh returns a Future, so the spinner waits for the first new
      // batch. invalidate returns nothing, so we would have to wrap it:
      //   onRefresh: () async => ref.invalidate(tickerProvider),
      onRefresh: () => ref.refresh(tickerProvider.future),
      child: ListView(
        // Lets the user pull even when the list is short.
        physics: const AlwaysScrollableScrollPhysics(),
        children: [for (final t in ticks) TickRow(t, key: ValueKey(t.symbol))],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ticks = ref.watch(tickerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Live ticker'),
        actions: [
          IconButton(
            tooltip: 'Make the feed fail after 5 batches',
            icon: const Icon(Icons.bug_report),
            onPressed: () => ref.read(failAfterProvider.notifier).state = 5,
          ),
          IconButton(
            tooltip: 'Make the feed stable again',
            icon: const Icon(Icons.check_circle_outline),
            onPressed: () => ref.read(failAfterProvider.notifier).state = null,
          ),
        ],
      ),
      // Arms are checked from top to bottom. The first one that matches wins,
      // so the specific arms must be above the general ones.
      body: switch (ticks) {
        // Error, but we still have old prices: dim rows + banner on top.
        AsyncError(:final error, :final value?) => Column(children: [
            MaterialBanner(
              content: Text('Feed error: $error — showing last prices'),
              actions: [
                TextButton(
                  onPressed: () => ref.invalidate(tickerProvider),
                  child: const Text('Retry'),
                ),
              ],
            ),
            Expanded(
              child: Opacity(opacity: 0.5, child: _rows(ref, value)),
            ),
          ]),

        // Error and nothing to show.
        AsyncError(:final error) => Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('Could not load ticker\n$error', textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => ref.invalidate(tickerProvider),
                child: const Text('Retry'),
              ),
            ]),
          ),

        // Refresh in progress: keep the rows, show a thin progress bar.
        AsyncValue(:final value?, isLoading: true) => Column(children: [
            const LinearProgressIndicator(),
            Expanded(child: _rows(ref, value)),
          ]),

        // Content arms must come before the general AsyncData arm.
        AsyncData(value: []) =>
          const Center(child: Text('No symbols subscribed')),
        AsyncData(value: [final only]) =>
          Center(child: TickRow(only)),

        AsyncData(:final value) => _rows(ref, value),

        // First load: nothing to show yet.
        AsyncLoading() => const Center(child: CircularProgressIndicator()),
      },
    );
  }
}
