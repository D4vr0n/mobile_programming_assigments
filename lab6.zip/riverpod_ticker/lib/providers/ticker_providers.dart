import 'package:flutter_riverpod/flutter_riverpod.dart';
// In Riverpod 3.x, StateProvider lives in the legacy import.
import 'package:flutter_riverpod/legacy.dart';

import '../models/tick.dart';
import '../services/tick_feed.dart';

/// null = never fail. A number = fail after that many batches.
/// Used by the AppBar buttons to show the error state on demand.
final failAfterProvider = StateProvider<int?>((ref) => null);

/// The feed has its own provider so tests (and the error demo) can replace it.
final tickFeedProvider = Provider<TickFeed>((ref) {
  return TickFeed(failAfter: ref.watch(failAfterProvider));
});

final tickerProvider = StreamProvider.autoDispose<List<Tick>>(
  (ref) {
    return ref.watch(tickFeedProvider).watch();
  },
  // Riverpod 3 retries failed providers by itself. We turn that off so the
  // error banner stays visible until the user taps Retry.
  retry: (retryCount, error) => null,
);
