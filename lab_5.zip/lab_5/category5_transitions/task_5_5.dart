// Task 5.5 - Reusable route and global theme
//
// Part 1: FadeRoute is a small reusable route. Any push becomes
//         Navigator.push(context, FadeRoute(const DetailsScreen())).
//
// Part 2: ThemeData(pageTransitionsTheme: ...) changes the default
//         transition for the whole app, without custom routes.
//         Here Android uses the iOS-style slide (Cupertino).
//
// Compare the two buttons on Home:
//   - "Open with FadeRoute"   -> our own fade
//   - "Open with normal push" -> uses the global theme (Cupertino slide)
//
// Run: flutter run -t lib/category5_transitions/task_5_5.dart

import 'package:flutter/material.dart';

class FadeRoute extends PageRouteBuilder<void> {
  final Widget page;

  FadeRoute(this.page)
      : super(
          transitionDuration: const Duration(milliseconds: 400),
          pageBuilder: (context, animation, secondaryAnimation) => page,
          transitionsBuilder:
              (context, animation, secondaryAnimation, child) {
            return FadeTransition(opacity: animation, child: child);
          },
        );
}

void main() {
  runApp(MaterialApp(
    theme: ThemeData(
      useMaterial3: true,
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        },
      ),
    ),
    home: const HomeScreen(),
  ));
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              child: const Text('Open with FadeRoute'),
              onPressed: () {
                Navigator.push(
                  context,
                  FadeRoute(const DetailsScreen(text: 'FadeRoute')),
                );
              },
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              child: const Text('Open with normal push'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        const DetailsScreen(text: 'Theme transition'),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsScreen extends StatelessWidget {
  final String text;
  const DetailsScreen({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: Center(child: Text(text, style: const TextStyle(fontSize: 22))),
    );
  }
}
