// Task 5.3 - Slide from the bottom
//
// A second button, "Open as a sheet", slides the screen up from the
// bottom (Offset(0, 1) -> Offset.zero). CurvedAnimation applies
// Curves.easeOut, and the duration is 500 ms.
//
// Run: flutter run -t lib/category5_transitions/task_5_3.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: HomeScreen()));

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              child: const Text('Open (slide from right)'),
              onPressed: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    transitionDuration: const Duration(milliseconds: 400),
                    pageBuilder: (context, animation, secondaryAnimation) =>
                        const DetailsScreen(text: 'From the right'),
                    transitionsBuilder:
                        (context, animation, secondaryAnimation, child) {
                      final offset = Tween<Offset>(
                        begin: const Offset(1, 0),
                        end: Offset.zero,
                      ).animate(animation);
                      return SlideTransition(position: offset, child: child);
                    },
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              child: const Text('Open as a sheet'),
              onPressed: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    transitionDuration: const Duration(milliseconds: 500),
                    pageBuilder: (context, animation, secondaryAnimation) =>
                        const DetailsScreen(text: 'From the bottom'),
                    transitionsBuilder:
                        (context, animation, secondaryAnimation, child) {
                      // The curve makes the motion start fast and slow down.
                      final curved = CurvedAnimation(
                        parent: animation,
                        curve: Curves.easeOut,
                      );

                      final offset = Tween<Offset>(
                        begin: const Offset(0, 1),
                        end: Offset.zero,
                      ).animate(curved);

                      return SlideTransition(position: offset, child: child);
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsScreen extends StatelessWidget {
  final String text;
  const DetailsScreen({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: Center(child: Text(text, style: const TextStyle(fontSize: 22))),
    );
  }
}
