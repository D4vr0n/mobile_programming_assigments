// Task 2.4 - Drawer navigation
//
// The drawer lists all routes. For drawer items we use
// pushReplacementNamed so the stack does not keep growing when the
// user switches between sections.
//
// We close the drawer first (Navigator.pop) and then navigate.
//
// Run: flutter run -t lib/category2_named_routes/task_2_4.dart

import 'package:flutter/material.dart';

class AppRoutes {
  static const home = '/';
  static const profile = '/profile';
  static const messages = '/messages';
  static const about = '/about';
}

void main() {
  runApp(MaterialApp(
    initialRoute: AppRoutes.home,
    routes: {
      AppRoutes.home: (context) => const SectionScreen(title: 'Home'),
      AppRoutes.profile: (context) => const SectionScreen(title: 'Profile'),
      AppRoutes.messages: (context) => const SectionScreen(title: 'Messages'),
      AppRoutes.about: (context) => const SectionScreen(title: 'About'),
    },
  ));
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, String route) {
    Navigator.pop(context); // close the drawer
    Navigator.pushReplacementNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Text('Menu',
                style: TextStyle(color: Colors.white, fontSize: 24)),
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home'),
            onTap: () => _go(context, AppRoutes.home),
          ),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Profile'),
            onTap: () => _go(context, AppRoutes.profile),
          ),
          ListTile(
            leading: const Icon(Icons.message),
            title: const Text('Messages'),
            onTap: () => _go(context, AppRoutes.messages),
          ),
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('About'),
            onTap: () => _go(context, AppRoutes.about),
          ),
        ],
      ),
    );
  }
}

/// Every section uses the same layout and the same drawer.
class SectionScreen extends StatelessWidget {
  final String title;
  const SectionScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      drawer: const AppDrawer(),
      body: Center(
        child: Text('$title section', style: const TextStyle(fontSize: 22)),
      ),
    );
  }
}
