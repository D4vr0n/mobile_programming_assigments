// Task 6.3 - Passing an object with extra
//
// context.push('/product-details', extra: product) sends a whole object.
// In the route builder we read it with state.extra and cast it.
//
// Question: what happens with extra when the app is reloaded in a browser?
// Answer: extra lives only in memory, it is not part of the URL. After a
// reload (or when someone opens the link directly) it is null, so the
// cast would crash. A path parameter is part of the URL, so it survives
// reloads, can be bookmarked and shared, and we can rebuild the screen
// from just the id.
//
// Run: flutter run -t lib/category6_go_router/task_6_3.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class Product {
  final String name;
  final double price;
  const Product(this.name, this.price);
}

const products = [
  Product('Laptop', 999.0),
  Product('Phone', 599.5),
  Product('Headphones', 79.9),
];

final router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const ProductListScreen(),
    ),
    GoRoute(
      path: '/product-details',
      builder: (context, state) {
        // extra can be null (for example after a browser reload),
        // so we check before using it.
        final product = state.extra;
        if (product is Product) {
          return ProductScreen(product: product);
        }
        return const Scaffold(
          body: Center(child: Text('No product was provided')),
        );
      },
    ),
  ],
);

void main() => runApp(MaterialApp.router(routerConfig: router));

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Products')),
      body: ListView(
        children: [
          for (final p in products)
            ListTile(
              title: Text(p.name),
              subtitle: Text('\$${p.price}'),
              onTap: () => context.push('/product-details', extra: p),
            ),
        ],
      ),
    );
  }
}

class ProductScreen extends StatelessWidget {
  final Product product;
  const ProductScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: Center(
        child: Text(
          'Price: \$${product.price}',
          style: const TextStyle(fontSize: 28),
        ),
      ),
    );
  }
}
