// Task 6.1 - First router: go, push and pop (sample)
//
// context.go   -> goes to a location and REPLACES the stack
// context.push -> adds the location on TOP of the stack
//
// Why does go have no back arrow? After go('/details') the stack only
// contains Details, so there is nothing to pop. After push('/details')
// Home is still below it, so the arrow and pop() work.
//
// Run: flutter run -t lib/category6_go_router/task_6_1.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/details',
      builder: (context, state) => const DetailsScreen(),
    ),
  ],
);

void main() => runApp(MaterialApp.router(routerConfig: router));

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () => context.go('/details'),
              child: const Text('go (replace stack)'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => context.push('/details'),
              child: const Text('push (add to stack)'),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsScreen extends StatelessWidget {
  const DetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: Center(
        child: ElevatedButton(
          // After go() this has nothing to pop; after push() it works.
          onPressed: () => context.pop(),
          child: const Text('pop'),
        ),
      ),
    );
  }
}
