// Task 6.5 - Transition in go_router
//
// Instead of `builder` we use `pageBuilder` and return a
// CustomTransitionPage. The transition code lives in one helper
// function, buildPage, which every route reuses.
//
// Home has three buttons that open three screens, each one with a
// different transition: fade, slide from the right, and scale + fade.
//
// Note: the task text suggests buildPage(Widget child). We also pass the
// GoRouterState, because CustomTransitionPage needs state.pageKey.
//
// Run: flutter run -t lib/category6_go_router/task_6_5.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// The three kinds of transition we can choose from.
enum PageEffect { fade, slide, scale }

/// Helper: builds a page with the chosen transition.
CustomTransitionPage<void> buildPage(
  GoRouterState state,
  Widget child, {
  PageEffect effect = PageEffect.fade,
}) {
  return CustomTransitionPage<void>(
    key: state.pageKey,
    transitionDuration: const Duration(milliseconds: 400),
    child: child,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      switch (effect) {
        case PageEffect.fade:
          return FadeTransition(opacity: animation, child: child);

        case PageEffect.slide:
          final offset = Tween<Offset>(
            begin: const Offset(1, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut));
          return SlideTransition(position: offset, child: child);

        case PageEffect.scale:
          final scale = Tween<double>(begin: 0.8, end: 1.0)
              .animate(CurvedAnimation(parent: animation, curve: Curves.easeOut));
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(scale: scale, child: child),
          );
      }
    },
  );
}

final router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/fade',
      pageBuilder: (context, state) => buildPage(
        state,
        const DetailsScreen(text: 'Fade'),
      ),
    ),
    GoRoute(
      path: '/slide',
      pageBuilder: (context, state) => buildPage(
        state,
        const DetailsScreen(text: 'Slide from the right'),
        effect: PageEffect.slide,
      ),
    ),
    GoRoute(
      path: '/scale',
      pageBuilder: (context, state) => buildPage(
        state,
        const DetailsScreen(text: 'Scale + fade'),
        effect: PageEffect.scale,
      ),
    ),
  ],
);

void main() => runApp(MaterialApp.router(routerConfig: router));

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () => context.push('/fade'),
              child: const Text('Fade'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => context.push('/slide'),
              child: const Text('Slide'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => context.push('/scale'),
              child: const Text('Scale + fade'),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsScreen extends StatelessWidget {
  final String text;
  const DetailsScreen({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: Center(child: Text(text, style: const TextStyle(fontSize: 22))),
    );
  }
}
