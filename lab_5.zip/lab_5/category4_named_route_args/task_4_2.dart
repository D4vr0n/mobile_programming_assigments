// Task 4.2 - Send a number
//
// Home has three buttons: 1, 2, 3. Each one opens /square and sends
// the number as a plain int. /square shows the number and its square.
//
// Run: flutter run -t lib/category4_named_route_args/task_4_2.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => const HomeScreen(),
      '/square': (context) => const SquareScreen(),
    },
  ));
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pick a number')),
      body: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final n in [1, 2, 3])
              Padding(
                padding: const EdgeInsets.all(8),
                child: ElevatedButton(
                  child: Text('$n'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/square', arguments: n);
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class SquareScreen extends StatelessWidget {
  const SquareScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final number = ModalRoute.of(context)!.settings.arguments as int;

    return Scaffold(
      appBar: AppBar(title: const Text('Square')),
      body: Center(
        child: Text(
          '$number squared is ${number * number}',
          style: const TextStyle(fontSize: 28),
        ),
      ),
    );
  }
}
