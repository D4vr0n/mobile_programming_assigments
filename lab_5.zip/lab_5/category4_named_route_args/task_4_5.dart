// Task 4.5 - Result from a named route
//
// Home opens /rate and sends the movie title as an argument.
// /rate has five star buttons and returns the chosen rating.
// Home then shows "Movie: 4/5".
//
// Question: what does Home show if the user leaves with the back arrow?
// Answer: pushNamed returns null, so we skip setState and Home keeps
// showing whatever it showed before ("Not rated yet" at first).
//
// Run: flutter run -t lib/category4_named_route_args/task_4_5.dart

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => const HomeScreen(),
      '/rate': (context) => const RateScreen(),
    },
  ));
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const movieTitle = 'Inception';
  int? _rating; // null means "not rated yet"

  Future<void> _rate() async {
    final rating = await Navigator.pushNamed<int>(
      context,
      '/rate',
      arguments: movieTitle,
    );

    if (!mounted) return;

    // The back arrow gives null -> keep the old value.
    if (rating != null) {
      setState(() => _rating = rating);
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = _rating == null
        ? 'Not rated yet'
        : '$movieTitle: $_rating/5';

    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(text, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _rate,
              child: const Text('Rate this movie'),
            ),
          ],
        ),
      ),
    );
  }
}

class RateScreen extends StatelessWidget {
  const RateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final title = ModalRoute.of(context)!.settings.arguments as String;

    return Scaffold(
      appBar: AppBar(title: Text('Rate: $title')),
      body: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var star = 1; star <= 5; star++)
              IconButton(
                icon: const Icon(Icons.star, color: Colors.amber),
                iconSize: 40,
                onPressed: () => Navigator.pop(context, star),
              ),
          ],
        ),
      ),
    );
  }
}
