// Task 4.4 - onGenerateRoute
//
// No `routes` table here. onGenerateRoute is called for every named
// navigation. For /profile we read the User from settings.arguments,
// check its type, and build ProfileScreen(user: user) through the
// constructor, so the screen itself stays type-safe.
//
// Run: flutter run -t lib/category4_named_route_args/task_4_4.dart

import 'package:flutter/material.dart';

class User {
  final String name;
  final int age;
  final String city;
  const User({required this.name, required this.age, required this.city});
}

const users = [
  User(name: 'Aziza', age: 20, city: 'Tashkent'),
  User(name: 'Bobur', age: 22, city: 'Samarkand'),
  User(name: 'Dilnoza', age: 19, city: 'Bukhara'),
  User(name: 'Jasur', age: 21, city: 'Namangan'),
];

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    onGenerateRoute: (settings) {
      if (settings.name == '/') {
        return MaterialPageRoute(
          builder: (context) => const UserListScreen(),
        );
      }

      if (settings.name == '/profile') {
        final args = settings.arguments;

        // Check the type instead of blindly casting.
        if (args is User) {
          return MaterialPageRoute(
            builder: (context) => ProfileScreen(user: args),
          );
        }
      }

      // Returning null lets Flutter fall back to onUnknownRoute.
      return null;
    },
    onUnknownRoute: (settings) {
      return MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(title: const Text('Error')),
          body: const Center(child: Text('Page not found')),
        ),
      );
    },
  ));
}

class UserListScreen extends StatelessWidget {
  const UserListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Users')),
      body: ListView(
        children: [
          for (final u in users)
            ListTile(
              title: Text(u.name),
              onTap: () {
                Navigator.pushNamed(context, '/profile', arguments: u);
              },
            ),
        ],
      ),
    );
  }
}

/// Now the screen takes a normal constructor parameter,
/// no ModalRoute lookup inside build.
class ProfileScreen extends StatelessWidget {
  final User user;
  const ProfileScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(user.name)),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Name: ${user.name}', style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 8),
            Text('Age: ${user.age}', style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 8),
            Text('City: ${user.city}', style: const TextStyle(fontSize: 22)),
          ],
        ),
      ),
    );
  }
}
