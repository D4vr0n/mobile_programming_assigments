// Task 1.1 - Two screens with push and pop (sample)
//
// Home has a button that opens Details with Navigator.push.
// Details has a button that goes back with Navigator.pop.
//
// Run: flutter run -t lib/category1_push_pop/task_1_1.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: HomeScreen()));

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: ElevatedButton(
          child: const Text('Open details'),
          onPressed: () {
            // push puts the new screen on top of the stack
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DetailsScreen()),
            );
          },
        ),
      ),
    );
  }
}

class DetailsScreen extends StatelessWidget {
  const DetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // The AppBar shows a back arrow by itself because there is
      // a screen below this one in the stack.
      appBar: AppBar(title: const Text('Details')),
      body: Center(
        child: ElevatedButton(
          child: const Text('Go back'),
          // pop removes the top screen
          onPressed: () => Navigator.pop(context),
        ),
      ),
    );
  }
}
