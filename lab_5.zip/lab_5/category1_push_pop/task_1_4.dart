// Task 1.4 - Back to the start
//
// Four screens: Step 1 -> Step 2 -> Step 3 -> Step 4.
// "Finish" on Step 4 removes Steps 2-4 in one go and shows Step 1.
//
// Run: flutter run -t lib/category1_push_pop/task_1_4.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: StepScreen(step: 1)));

class StepScreen extends StatelessWidget {
  final int step;
  const StepScreen({super.key, required this.step});

  @override
  Widget build(BuildContext context) {
    final isLast = step == 4;

    return Scaffold(
      appBar: AppBar(title: Text('Step $step')),
      body: Center(
        child: isLast
            ? ElevatedButton(
                child: const Text('Finish'),
                onPressed: () {
                  // Keep popping until we reach the first route in the stack.
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
              )
            : ElevatedButton(
                child: const Text('Next step'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => StepScreen(step: step + 1),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
