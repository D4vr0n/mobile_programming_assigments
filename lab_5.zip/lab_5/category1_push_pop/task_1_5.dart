// Task 1.5 - Smart back button
//
// BackOrExitButton checks Navigator.canPop(context):
//   - true  -> button says "Back" and pops the screen
//   - false -> button is disabled and says "Nothing to go back to"
//
// The root screen shows the disabled version, the pushed screen shows
// the active one.
//
// Run: flutter run -t lib/category1_push_pop/task_1_5.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: RootScreen()));

class BackOrExitButton extends StatelessWidget {
  const BackOrExitButton({super.key});

  @override
  Widget build(BuildContext context) {
    final canGoBack = Navigator.canPop(context);

    return ElevatedButton(
      // onPressed: null disables the button
      onPressed: canGoBack ? () => Navigator.pop(context) : null,
      child: Text(canGoBack ? 'Back' : 'Nothing to go back to'),
    );
  }
}

class RootScreen extends StatelessWidget {
  const RootScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Root screen')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const BackOrExitButton(), // disabled here
            const SizedBox(height: 16),
            ElevatedButton(
              child: const Text('Open pushed screen'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PushedScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class PushedScreen extends StatelessWidget {
  const PushedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pushed screen')),
      body: const Center(
        child: BackOrExitButton(), // active here
      ),
    );
  }
}
