// Task 1.3 - Replace, do not stack
//
// After "Sign in" the user lands on Home and cannot go back to Login.
// pushReplacement swaps the current screen instead of adding a new one.
//
// Compare: if you change pushReplacement to push, Home gets a back
// arrow and the user can return to the Login screen.
//
// Run: flutter run -t lib/category1_push_pop/task_1_3.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: LoginScreen()));

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: ElevatedButton(
          child: const Text('Sign in'),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
            );
          },
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // No back arrow here, because Login was removed from the stack.
      appBar: AppBar(title: const Text('Home')),
      body: const Center(
        child: Text('Welcome! You are signed in.',
            style: TextStyle(fontSize: 22)),
      ),
    );
  }
}
