// Task 3.3 - Contact card
//
// A list of 5 contacts. Tapping one opens ContactScreen, which shows
// name, phone and email in a card. We pass the whole Contact object,
// not three separate strings.
//
// Run: flutter run -t lib/category3_constructor_args/task_3_3.dart

import 'package:flutter/material.dart';

class Contact {
  final String name;
  final String phone;
  final String email;
  const Contact({
    required this.name,
    required this.phone,
    required this.email,
  });
}

const contacts = [
  Contact(name: 'Aziza Karimova', phone: '+998 90 111 22 33', email: 'aziza@example.com'),
  Contact(name: 'Bobur Rahimov', phone: '+998 91 222 33 44', email: 'bobur@example.com'),
  Contact(name: 'Dilnoza Yusupova', phone: '+998 93 333 44 55', email: 'dilnoza@example.com'),
  Contact(name: 'Jasur Tursunov', phone: '+998 94 444 55 66', email: 'jasur@example.com'),
  Contact(name: 'Malika Saidova', phone: '+998 95 555 66 77', email: 'malika@example.com'),
];

void main() => runApp(const MaterialApp(home: ContactListScreen()));

class ContactListScreen extends StatelessWidget {
  const ContactListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contacts')),
      body: ListView(
        children: [
          for (final c in contacts)
            ListTile(
              leading: CircleAvatar(child: Text(c.name[0])),
              title: Text(c.name),
              subtitle: Text(c.phone),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ContactScreen(contact: c),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}

class ContactScreen extends StatelessWidget {
  final Contact contact;
  const ContactScreen({super.key, required this.contact});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(contact.name)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Card(
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(contact.name,
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.bold)),
                const Divider(height: 24),
                Row(children: [
                  const Icon(Icons.phone),
                  const SizedBox(width: 12),
                  Text(contact.phone),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  const Icon(Icons.email),
                  const SizedBox(width: 12),
                  Text(contact.email),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
