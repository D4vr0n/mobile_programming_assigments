// Task 3.4 - Pick a colour (result back)
//
// Screen 1 shows a square with the current colour.
// Screen 2 has three coloured buttons. Tapping one closes screen 2
// and sends the colour back with Navigator.pop(context, colour).
//
// Run: flutter run -t lib/category3_constructor_args/task_3_4.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: HomeScreen()));

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Color _color = Colors.grey;

  Future<void> _chooseColor() async {
    // Wait here until the other screen is closed.
    final chosen = await Navigator.push<Color>(
      context,
      MaterialPageRoute(builder: (context) => const ColorPickerScreen()),
    );

    // Never use context after an await without checking mounted.
    if (!mounted) return;

    // chosen is null if the user pressed the back arrow.
    if (chosen != null) {
      setState(() => _color = chosen);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Current colour')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 120, height: 120, color: _color),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _chooseColor,
              child: const Text('Choose colour'),
            ),
          ],
        ),
      ),
    );
  }
}

class ColorPickerScreen extends StatelessWidget {
  const ColorPickerScreen({super.key});

  Widget _colorButton(BuildContext context, Color color, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          minimumSize: const Size(200, 48),
        ),
        // The second argument of pop is the result.
        onPressed: () => Navigator.pop(context, color),
        child: Text(label),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pick a colour')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _colorButton(context, Colors.red, 'Red'),
            _colorButton(context, Colors.green, 'Green'),
            _colorButton(context, Colors.blue, 'Blue'),
          ],
        ),
      ),
    );
  }
}
