// Task 3.2 - Greeting
//
// Screen 1 has a TextField and a "Greet" button.
// Screen 2 shows "Hello, <name>!" using a value passed in its constructor.
//
// Run: flutter run -t lib/category3_constructor_args/task_3_2.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: NameScreen()));

class NameScreen extends StatefulWidget {
  const NameScreen({super.key});

  @override
  State<NameScreen> createState() => _NameScreenState();
}

class _NameScreenState extends State<NameScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Enter your name')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              child: const Text('Greet'),
              onPressed: () {
                final name = _controller.text.trim();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GreetingScreen(name: name),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class GreetingScreen extends StatelessWidget {
  final String name;
  const GreetingScreen({super.key, required this.name});

  @override
  Widget build(BuildContext context) {
    // If the user typed nothing, say hello to "stranger".
    final shown = name.isEmpty ? 'stranger' : name;

    return Scaffold(
      appBar: AppBar(title: const Text('Greeting')),
      body: Center(
        child: Text('Hello, $shown!', style: const TextStyle(fontSize: 30)),
      ),
    );
  }
}
