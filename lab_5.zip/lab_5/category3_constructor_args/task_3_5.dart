// Task 3.5 - Edit a counter
//
// Screen 1 keeps an integer and sends it to the Editor screen.
// The Editor has + and - buttons.
//   - "Save"       -> returns the new value
//   - back arrow   -> returns null, so screen 1 keeps the old value
//
// Run: flutter run -t lib/category3_constructor_args/task_3_5.dart

import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: HomeScreen()));

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _value = 0;

  Future<void> _edit() async {
    final result = await Navigator.push<int>(
      context,
      MaterialPageRoute(
        // Send the current value forward through the constructor.
        builder: (context) => EditorScreen(initialValue: _value),
      ),
    );

    if (!mounted) return;

    // Handle null: the user left without saving.
    if (result == null) return;

    setState(() => _value = result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Counter')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Value: $_value', style: const TextStyle(fontSize: 32)),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _edit, child: const Text('Edit')),
          ],
        ),
      ),
    );
  }
}

class EditorScreen extends StatefulWidget {
  final int initialValue;
  const EditorScreen({super.key, required this.initialValue});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late int _value;

  @override
  void initState() {
    super.initState();
    // Work on a copy so the old value stays safe until Save.
    _value = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Editor')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  iconSize: 40,
                  onPressed: () => setState(() => _value--),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text('$_value', style: const TextStyle(fontSize: 32)),
                ),
                IconButton(
                  icon: const Icon(Icons.add_circle_outline),
                  iconSize: 40,
                  onPressed: () => setState(() => _value++),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              child: const Text('Save'),
              onPressed: () => Navigator.pop(context, _value),
            ),
          ],
        ),
      ),
    );
  }
}
