import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// Logs Cubit changes (state -> state) and Bloc transitions (state -> event ->
/// state). The extra "event" in the Bloc log is what a Cubit cannot give you.
class AppBlocObserver extends BlocObserver {
  @override
  void onChange(BlocBase<dynamic> bloc, Change<dynamic> change) {
    super.onChange(bloc, change);
    debugPrint('[change] ${bloc.runtimeType}: ${change.currentState} -> ${change.nextState}');
  }

  @override
  void onTransition(Bloc<dynamic, dynamic> bloc, Transition<dynamic, dynamic> transition) {
    super.onTransition(bloc, transition);
    debugPrint('[transition] ${bloc.runtimeType}: ${transition.currentState} '
        '--${transition.event.runtimeType}--> ${transition.nextState}');
  }
}
