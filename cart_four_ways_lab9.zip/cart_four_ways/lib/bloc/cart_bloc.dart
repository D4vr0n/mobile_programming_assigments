import 'package:bloc_concurrency/bloc_concurrency.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';
import 'cart_event.dart';

class CartBloc extends Bloc<CartEvent, CartState> {
  CartBloc(this._api) : super(const CartState()) {
    on<CartProductAdded>((e, emit) => _mutate(e, emit, (s) => s.withProduct(e.product)));
    on<CartQtyChanged>((e, emit) => _mutate(e, emit, (s) => s.withQtyChange(e.productId, e.delta)));
    on<CartCouponApplied>((e, emit) => _mutate(e, emit, (s) => s.withCoupon(e.code)));
    on<CartUndone>(_onUndone);
    // droppable(): while one checkout is running, further requests are ignored.
    on<CartCheckoutRequested>(_onCheckout, transformer: droppable());
  }

  final CheckoutApi _api;
  final _history = <CartState>[];

  void _mutate(CartEvent event, Emitter<CartState> emit, CartState Function(CartState) change) {
    final next = change(state).copyWith(canUndo: true);
    if (next == state) return;
    if (event.isUndoable) _history.add(state);
    emit(next);
  }

  void _onUndone(CartUndone event, Emitter<CartState> emit) {
    if (_history.isEmpty) return;
    final prev = _history.removeLast();
    emit(state.restored(prev, canUndo: _history.isNotEmpty));
  }

  Future<void> _onCheckout(CartCheckoutRequested event, Emitter<CartState> emit) async {
    emit(state.checkoutStarted());
    try {
      final id = await _api.submit(state.total);
      if (emit.isDone) return; // bloc closed while waiting
      _history.clear();
      emit(state.checkoutSucceeded(id));
    } on CheckoutException catch (e) {
      if (emit.isDone) return;
      emit(state.checkoutFailed(e.message));
    }
  }
}
