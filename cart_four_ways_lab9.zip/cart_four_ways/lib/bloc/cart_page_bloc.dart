import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';
import '../widgets/cart_body.dart';
import '../widgets/checkout_button.dart';
import '../widgets/checkout_feedback.dart';
import '../widgets/coupon_field.dart';
import '../widgets/summary_view.dart';
import 'cart_bloc.dart';
import 'cart_event.dart';

class BlocCartPage extends StatelessWidget {
  const BlocCartPage({super.key});

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (_) => CartBloc(CheckoutApi()),
        child: const _BlocCartView(),
      );
}

class _BlocCartView extends StatelessWidget {
  const _BlocCartView();

  @override
  Widget build(BuildContext context) => BlocListener<CartBloc, CartState>(
        listenWhen: (p, c) => p.status != c.status,
        listener: (context, s) =>
            showCheckoutFeedback(context, s.status, orderId: s.orderId, error: s.checkoutError),
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Cart · Bloc'),
            actions: [
              BlocSelector<CartBloc, CartState, bool>(
                selector: (s) => s.canUndo,
                builder: (context, canUndo) => IconButton(
                  tooltip: 'Undo',
                  icon: const Icon(Icons.undo),
                  onPressed: canUndo ? () => context.read<CartBloc>().add(const CartUndone()) : null,
                ),
              ),
            ],
          ),
          body: BlocBuilder<CartBloc, CartState>(
            builder: (context, state) {
              final bloc = context.read<CartBloc>();
              return CartBody(
                lines: state.lines,
                onAdd: (p) => bloc.add(CartProductAdded(p)), // the UI adds, never calls
                onQtyChanged: (id, delta) => bloc.add(CartQtyChanged(id, delta)),
                coupon: CouponField(
                  error: state.couponError,
                  onApply: (code) => bloc.add(CartCouponApplied(code)),
                ),
                summary: const _BlocSummaryCard(),
                checkout: CheckoutButton(
                  busy: state.status == CheckoutStatus.submitting,
                  enabled: state.lines.isNotEmpty,
                  onPressed: () => bloc.add(const CartCheckoutRequested()),
                ),
              );
            },
          ),
        ),
      );
}

class _BlocSummaryCard extends StatelessWidget {
  const _BlocSummaryCard();

  @override
  Widget build(BuildContext context) => BlocSelector<CartBloc, CartState, CartSummary>(
        selector: (s) => s.summary,
        builder: (context, summary) => SummaryView(summary, debugLabel: 'Bloc'),
      );
}
