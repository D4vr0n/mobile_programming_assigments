import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';

class CartCubit extends Cubit<CartState> {
  CartCubit(this._api) : super(const CartState());

  final CheckoutApi _api;
  final _history = <CartState>[]; // T5: inside the cubit; the UI sees state.canUndo

  void _apply(CartState Function(CartState) change) {
    final next = change(state).copyWith(canUndo: true);
    if (next == state) return; // emit would be dropped; do not record history either
    _history.add(state);
    emit(next);
  }

  void add(Product p) => _apply((s) => s.withProduct(p));
  void changeQty(String id, int delta) => _apply((s) => s.withQtyChange(id, delta));
  void applyCoupon(String code) => _apply((s) => s.withCoupon(code));

  void undo() {
    if (_history.isEmpty) return;
    final prev = _history.removeLast();
    emit(state.restored(prev, canUndo: _history.isNotEmpty));
  }

  Future<void> checkout() async {
    if (state.status == CheckoutStatus.submitting) return; // drop duplicate taps by hand
    emit(state.checkoutStarted());
    try {
      final id = await _api.submit(state.total);
      if (isClosed) return; // page left mid-checkout: emit after close() would throw
      _history.clear();
      emit(state.checkoutSucceeded(id));
    } on CheckoutException catch (e) {
      if (isClosed) return;
      emit(state.checkoutFailed(e.message));
    }
  }
}
