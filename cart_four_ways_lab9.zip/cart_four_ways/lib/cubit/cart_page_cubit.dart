import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';
import '../widgets/cart_body.dart';
import '../widgets/checkout_button.dart';
import '../widgets/checkout_feedback.dart';
import '../widgets/coupon_field.dart';
import '../widgets/summary_view.dart';
import 'cart_cubit.dart';

class CubitCartPage extends StatelessWidget {
  const CubitCartPage({super.key});

  @override
  Widget build(BuildContext context) => BlocProvider(
        create: (_) => CartCubit(CheckoutApi()), // scoped to this page, closed on dispose
        child: const _CubitCartView(),
      );
}

/// Lives *below* the BlocProvider so context.read<CartCubit>() can find it.
class _CubitCartView extends StatelessWidget {
  const _CubitCartView();

  @override
  Widget build(BuildContext context) => BlocListener<CartCubit, CartState>(
        listenWhen: (p, c) => p.status != c.status, // side effects only on status change
        listener: (context, s) =>
            showCheckoutFeedback(context, s.status, orderId: s.orderId, error: s.checkoutError),
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Cart · Cubit'),
            actions: [
              BlocSelector<CartCubit, CartState, bool>(
                selector: (s) => s.canUndo,
                builder: (context, canUndo) => IconButton(
                  tooltip: 'Undo',
                  icon: const Icon(Icons.undo),
                  onPressed: canUndo ? context.read<CartCubit>().undo : null,
                ),
              ),
            ],
          ),
          body: BlocBuilder<CartCubit, CartState>(
            builder: (context, state) {
              final cubit = context.read<CartCubit>(); // lookup without subscribing
              return CartBody(
                lines: state.lines,
                onAdd: cubit.add,
                onQtyChanged: cubit.changeQty,
                coupon: CouponField(error: state.couponError, onApply: cubit.applyCoupon),
                summary: const _CubitSummaryCard(), // const: parent rebuilds skip it
                checkout: CheckoutButton(
                  busy: state.status == CheckoutStatus.submitting,
                  enabled: state.lines.isNotEmpty,
                  onPressed: cubit.checkout,
                ),
              );
            },
          ),
        ),
      );
}

class _CubitSummaryCard extends StatelessWidget {
  const _CubitSummaryCard();

  @override
  Widget build(BuildContext context) => BlocSelector<CartCubit, CartState, CartSummary>(
        selector: (s) => s.summary,
        builder: (context, summary) => SummaryView(summary, debugLabel: 'Cubit'),
      );
}
