import 'package:flutter/material.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';
import '../widgets/cart_body.dart';
import '../widgets/checkout_button.dart';
import '../widgets/checkout_feedback.dart';
import '../widgets/coupon_field.dart';
import '../widgets/summary_view.dart';

class SetStateCartPage extends StatefulWidget {
  const SetStateCartPage({super.key});

  @override
  State<SetStateCartPage> createState() => _SetStateCartPageState();
}

class _SetStateCartPageState extends State<SetStateCartPage> {
  final _api = CheckoutApi();
  CartState _state = const CartState(); // state is a field on the State object
  final List<CartState> _history = []; // T5: dies with this State object

  /// Every undoable mutation goes through here: compute, push history, setState.
  void _mutate(CartState Function(CartState) change) {
    final next = change(_state);
    if (next == _state) return;
    _history.add(_state);
    setState(() => _state = next);
  }

  void _add(Product p) => _mutate((s) => s.withProduct(p));
  void _changeQty(String id, int delta) => _mutate((s) => s.withQtyChange(id, delta));
  void _applyCoupon(String code) => _mutate((s) => s.withCoupon(code));

  void _undo() {
    if (_history.isEmpty) return;
    final prev = _history.removeLast();
    setState(() => _state = _state.restored(prev, canUndo: false));
  }

  Future<void> _checkout() async {
    if (_state.status == CheckoutStatus.submitting) return;
    setState(() => _state = _state.checkoutStarted());
    showCheckoutFeedback(context, _state.status); // hides a stale banner
    try {
      final id = await _api.submit(_state.total);
      // Without this guard, setState below runs on a disposed State if the user
      // left the page while the request was in flight.
      if (!mounted) return;
      _history.clear();
      setState(() => _state = _state.checkoutSucceeded(id));
      showCheckoutFeedback(context, _state.status, orderId: _state.orderId);
    } on CheckoutException catch (e) {
      if (!mounted) return;
      setState(() => _state = _state.checkoutFailed(e.message));
      showCheckoutFeedback(context, _state.status, error: _state.checkoutError);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Cart · setState'),
          actions: [
            IconButton(
              tooltip: 'Undo',
              icon: const Icon(Icons.undo),
              onPressed: _history.isEmpty ? null : _undo,
            ),
          ],
        ),
        body: CartBody(
          lines: _state.lines,
          onAdd: _add,
          onQtyChanged: _changeQty,
          coupon: CouponField(error: _state.couponError, onApply: _applyCoupon),
          summary: SummaryView(_state.summary, debugLabel: 'setState'),
          checkout: CheckoutButton(
            busy: _state.status == CheckoutStatus.submitting,
            enabled: _state.lines.isNotEmpty,
            onPressed: _checkout,
          ),
        ),
      );
}
