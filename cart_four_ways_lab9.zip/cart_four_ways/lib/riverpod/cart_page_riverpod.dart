import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/cart.dart';
import '../widgets/cart_body.dart';
import '../widgets/checkout_button.dart';
import '../widgets/checkout_feedback.dart';
import '../widgets/coupon_field.dart';
import '../widgets/summary_view.dart';
import 'cart_notifier.dart';

class RiverpodCartPage extends ConsumerWidget {
  const RiverpodCartPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(cartProvider); // subscribe: rebuild on change
    final canUndo = ref.watch(canUndoProvider);
    final cart = ref.read(cartProvider.notifier); // method handle, no subscription

    // Side effects belong in listen, never in build.
    ref.listen<CheckoutStatus>(cartProvider.select((s) => s.status), (prev, next) {
      final s = ref.read(cartProvider);
      showCheckoutFeedback(context, next, orderId: s.orderId, error: s.checkoutError);
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cart · Riverpod'),
        actions: [
          IconButton(
            tooltip: 'Undo',
            icon: const Icon(Icons.undo),
            onPressed: canUndo ? cart.undo : null,
          ),
        ],
      ),
      body: CartBody(
        lines: state.lines,
        onAdd: cart.add,
        onQtyChanged: cart.changeQty,
        coupon: CouponField(error: state.couponError, onApply: cart.applyCoupon),
        summary: const _RiverpodSummaryCard(), // const: parent rebuilds skip it
        checkout: CheckoutButton(
          busy: state.status == CheckoutStatus.submitting,
          enabled: state.lines.isNotEmpty,
          onPressed: cart.checkout,
        ),
      ),
    );
  }
}

/// Watches only the summary values, so it rebuilds only when they change.
class _RiverpodSummaryCard extends ConsumerWidget {
  const _RiverpodSummaryCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summary = ref.watch(cartProvider.select((s) => s.summary));
    return SummaryView(summary, debugLabel: 'Riverpod');
  }
}
