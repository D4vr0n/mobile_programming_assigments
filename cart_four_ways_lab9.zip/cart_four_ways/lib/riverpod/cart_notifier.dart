import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/cart.dart';
import '../services/checkout_api.dart';

final checkoutApiProvider = Provider<CheckoutApi>((ref) => CheckoutApi());

class CartNotifier extends Notifier<CartState> {
  final _history = <CartState>[]; // T5: private field, dies with this notifier

  @override
  CartState build() {
    _history.clear(); // build re-runs on invalidate: start from a clean slate
    return const CartState();
  }

  bool get canUndo => _history.isNotEmpty;

  void _apply(CartState Function(CartState) change) {
    final next = change(state);
    if (next == state) return; // equal state would not notify; do not record it either
    _history.add(state);
    state = next;
  }

  void add(Product p) => _apply((s) => s.withProduct(p));
  void changeQty(String id, int delta) => _apply((s) => s.withQtyChange(id, delta));
  void applyCoupon(String code) => _apply((s) => s.withCoupon(code));

  void undo() {
    if (_history.isEmpty) return;
    final prev = _history.removeLast();
    state = state.restored(prev, canUndo: false);
  }

  Future<void> checkout() async {
    if (state.status == CheckoutStatus.submitting) return;
    final api = ref.read(checkoutApiProvider);
    state = state.checkoutStarted();
    try {
      final id = await api.submit(state.total);
      _history.clear();
      state = state.checkoutSucceeded(id);
    } on CheckoutException catch (e) {
      state = state.checkoutFailed(e.message);
    }
  }
}

final cartProvider = NotifierProvider<CartNotifier, CartState>(CartNotifier.new);

/// The history is a plain field, so it is not observable by itself. Every
/// mutation also changes the cart state, so watching [cartProvider] makes this
/// re-evaluate exactly when the answer may have changed.
final canUndoProvider = Provider<bool>((ref) {
  ref.watch(cartProvider);
  return ref.read(cartProvider.notifier).canUndo;
});
