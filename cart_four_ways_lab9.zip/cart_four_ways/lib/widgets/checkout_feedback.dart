import 'package:flutter/material.dart';

import '../models/cart.dart';

/// Side effect for a checkout status change: SnackBar on success, MaterialBanner
/// on failure. Called from build-free places only (listeners / event handlers),
/// never from build.
void showCheckoutFeedback(
  BuildContext context,
  CheckoutStatus status, {
  String? orderId,
  String? error,
}) {
  final messenger = ScaffoldMessenger.of(context);
  switch (status) {
    case CheckoutStatus.idle:
      break;
    case CheckoutStatus.submitting:
      messenger.hideCurrentMaterialBanner();
    case CheckoutStatus.success:
      messenger.hideCurrentMaterialBanner();
      messenger.showSnackBar(SnackBar(content: Text('Order ${orderId ?? ''} placed')));
    case CheckoutStatus.failure:
      messenger.showMaterialBanner(MaterialBanner(
        content: Text(error ?? 'Checkout failed'),
        actions: [
          TextButton(
            onPressed: () => messenger.hideCurrentMaterialBanner(),
            child: const Text('Dismiss'),
          ),
        ],
      ));
  }
}
