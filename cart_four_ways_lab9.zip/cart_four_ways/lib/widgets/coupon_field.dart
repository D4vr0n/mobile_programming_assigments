import 'package:flutter/material.dart';

/// Dumb coupon input. The typed text lives in a local controller (it is UI
/// state, not cart state); only the Apply press and the error come from outside.
class CouponField extends StatefulWidget {
  const CouponField({super.key, required this.error, required this.onApply});

  final String? error;
  final ValueChanged<String> onApply;

  @override
  State<CouponField> createState() => _CouponFieldState();
}

class _CouponFieldState extends State<CouponField> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Coupon code',
                errorText: widget.error, // rendered in the theme's error (red) colour
                isDense: true,
              ),
            ),
          ),
          const SizedBox(width: 8),
          FilledButton.tonal(
            onPressed: () => widget.onApply(_controller.text),
            child: const Text('Apply'),
          ),
        ]),
      );
}
