import 'package:flutter/material.dart';

import '../models/cart.dart';

/// Dumb UI shared by all four styles: data and callbacks in, widgets out.
/// The coupon field, summary card and checkout button are passed in as slots so
/// each style can wire them up with its own subscription mechanism.
class CartBody extends StatelessWidget {
  const CartBody({
    super.key,
    required this.lines,
    required this.onAdd,
    required this.onQtyChanged,
    required this.coupon,
    required this.summary,
    required this.checkout,
  });

  final List<CartLine> lines;
  final void Function(Product) onAdd;
  final void Function(String productId, int delta) onQtyChanged;
  final Widget coupon;
  final Widget summary;
  final Widget checkout;

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(spacing: 8, children: [
            for (final p in catalog)
              ActionChip(
                label: Text('${p.name} · ${p.price.toStringAsFixed(0)}'),
                onPressed: () => onAdd(p),
              ),
          ]),
        ),
        Expanded(
          child: lines.isEmpty
              ? const Center(child: Text('Cart is empty'))
              : ListView(children: [
                  for (final l in lines)
                    ListTile(
                      key: ValueKey(l.product.id),
                      title: Text(l.product.name),
                      subtitle: Text('× ${l.qty}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                          tooltip: 'Remove one',
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () => onQtyChanged(l.product.id, -1),
                        ),
                        IconButton(
                          tooltip: 'Add one',
                          icon: const Icon(Icons.add_circle_outline),
                          onPressed: () => onQtyChanged(l.product.id, 1),
                        ),
                      ]),
                    ),
                ]),
        ),
        coupon,
        summary,
        checkout,
      ]);
}
