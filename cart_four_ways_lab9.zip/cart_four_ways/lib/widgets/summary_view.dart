import 'package:flutter/material.dart';

import '../models/cart.dart';

/// Summary card (item count, subtotal, discount, total). It prints a line every
/// time it is rebuilt so the four styles can be compared (T3).
class SummaryView extends StatelessWidget {
  const SummaryView(this.summary, {super.key, required this.debugLabel});

  final CartSummary summary;
  final String debugLabel;

  @override
  Widget build(BuildContext context) {
    debugPrint('[$debugLabel] SummaryView rebuilt');
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          _row('Items', '${summary.itemCount}'),
          _row('Subtotal', summary.subtotal.toStringAsFixed(2)),
          _row('Discount',
              summary.discount == 0 ? '0.00' : '-${summary.discount.toStringAsFixed(2)}'),
          _row('Total', summary.total.toStringAsFixed(2), bold: true),
        ]),
      ),
    );
  }

  Widget _row(String label, String value, {bool bold = false}) {
    final style = bold ? const TextStyle(fontWeight: FontWeight.bold) : null;
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: style),
      Text(value, style: style),
    ]);
  }
}
