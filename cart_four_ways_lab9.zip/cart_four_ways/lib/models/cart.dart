import 'package:flutter/foundation.dart';

class Product {
  const Product({required this.id, required this.name, required this.price});
  final String id;
  final String name;
  final double price;

  @override
  bool operator ==(Object other) =>
      other is Product && other.id == id && other.name == name && other.price == price;

  @override
  int get hashCode => Object.hash(id, name, price);
}

const catalog = [
  Product(id: 'p1', name: 'Keyboard', price: 49),
  Product(id: 'p2', name: 'Mouse', price: 25),
  Product(id: 'p3', name: 'Monitor', price: 199),
];

class CartLine {
  const CartLine({required this.product, required this.qty});
  final Product product;
  final int qty;

  double get subtotal => product.price * qty;

  CartLine copyWith({int? qty}) => CartLine(product: product, qty: qty ?? this.qty);

  @override
  bool operator ==(Object other) =>
      other is CartLine && other.product == product && other.qty == qty;

  @override
  int get hashCode => Object.hash(product, qty);
}

/// Pure, style-independent cart logic. Every state holder calls these.
extension CartLines on List<CartLine> {
  List<CartLine> withProduct(Product p) {
    final i = indexWhere((l) => l.product.id == p.id);
    if (i == -1) return [...this, CartLine(product: p, qty: 1)];
    return [for (final l in this) l.product.id == p.id ? l.copyWith(qty: l.qty + 1) : l];
  }

  List<CartLine> without(String productId) =>
      [for (final l in this) if (l.product.id != productId) l];

  /// Adds [delta] to the quantity of [id]; a line whose quantity would drop to
  /// zero (or below) is removed.
  List<CartLine> changeQty(String id, int delta) => [
        for (final l in this)
          if (l.product.id != id)
            l
          else if (l.qty + delta > 0)
            l.copyWith(qty: l.qty + delta),
      ];

  double get subtotal => fold<double>(0, (s, l) => s + l.subtotal);
  int get itemCount => fold<int>(0, (s, l) => s + l.qty);
}

enum CheckoutStatus { idle, submitting, success, failure }

/// Records have structural equality, so a selector returning this only
/// triggers a rebuild when one of the four values really changes.
typedef CartSummary = ({int itemCount, double subtotal, double discount, double total});

const _unset = Object();

/// Immutable cart state shared by all four styles. Every transition is a pure
/// method here, so the state holders only decide *where* state lives.
class CartState {
  const CartState({
    this.lines = const [],
    this.coupon,
    this.couponError,
    this.status = CheckoutStatus.idle,
    this.orderId,
    this.checkoutError,
    this.canUndo = false,
  });

  static const validCoupon = 'SAVE10';
  static const _couponRate = 0.10;

  final List<CartLine> lines;
  final String? coupon;
  final String? couponError;
  final CheckoutStatus status;
  final String? orderId;
  final String? checkoutError;

  /// Only used by Cubit and Bloc (history lives inside the holder there, so the
  /// UI needs an observable flag). setState and Riverpod derive it elsewhere.
  final bool canUndo;

  // T3: derived values are getters, never stored fields.
  int get itemCount => lines.itemCount;
  double get subtotal => lines.subtotal;
  double get discount => coupon == validCoupon ? subtotal * _couponRate : 0.0;
  double get total => subtotal - discount;
  CartSummary get summary =>
      (itemCount: itemCount, subtotal: subtotal, discount: discount, total: total);

  CartState copyWith({
    List<CartLine>? lines,
    Object? coupon = _unset,
    Object? couponError = _unset,
    CheckoutStatus? status,
    Object? orderId = _unset,
    Object? checkoutError = _unset,
    bool? canUndo,
  }) =>
      CartState(
        lines: lines ?? this.lines,
        coupon: identical(coupon, _unset) ? this.coupon : coupon as String?,
        couponError: identical(couponError, _unset) ? this.couponError : couponError as String?,
        status: status ?? this.status,
        orderId: identical(orderId, _unset) ? this.orderId : orderId as String?,
        checkoutError:
            identical(checkoutError, _unset) ? this.checkoutError : checkoutError as String?,
        canUndo: canUndo ?? this.canUndo,
      );

  // ---- pure transitions -------------------------------------------------

  CartState withProduct(Product p) => copyWith(lines: lines.withProduct(p));

  CartState withQtyChange(String id, int delta) =>
      copyWith(lines: lines.changeQty(id, delta));

  CartState withCoupon(String code) {
    final c = code.trim().toUpperCase();
    if (c == validCoupon) return copyWith(coupon: c, couponError: null);
    return copyWith(couponError: 'Invalid coupon code');
  }

  CartState checkoutStarted() =>
      copyWith(status: CheckoutStatus.submitting, orderId: null, checkoutError: null);

  /// A successful checkout empties the cart and the undo history.
  CartState checkoutSucceeded(String orderId) =>
      CartState(status: CheckoutStatus.success, orderId: orderId);

  CartState checkoutFailed(String message) =>
      copyWith(status: CheckoutStatus.failure, checkoutError: message);

  /// Restores the cart contents of [prev]; checkout status is reset to idle.
  CartState restored(CartState prev, {required bool canUndo}) => copyWith(
        lines: prev.lines,
        coupon: prev.coupon,
        couponError: prev.couponError,
        status: CheckoutStatus.idle,
        orderId: null,
        checkoutError: null,
        canUndo: canUndo,
      );

  // ---- value equality (Riverpod, Cubit and Bloc all skip equal states) ----

  @override
  bool operator ==(Object other) =>
      other is CartState &&
      listEquals(other.lines, lines) &&
      other.coupon == coupon &&
      other.couponError == couponError &&
      other.status == status &&
      other.orderId == orderId &&
      other.checkoutError == checkoutError &&
      other.canUndo == canUndo;

  @override
  int get hashCode => Object.hash(
        Object.hashAll(lines),
        coupon,
        couponError,
        status,
        orderId,
        checkoutError,
        canUndo,
      );

  @override
  String toString() => 'CartState(items: $itemCount, coupon: $coupon, '
      'couponError: $couponError, status: ${status.name}, canUndo: $canUndo)';
}
