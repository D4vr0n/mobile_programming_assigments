# Lab 9 notes: One Cart, Four Ways

Pair: _(fill in names)_  ·  Everything below describes the code in this repo.

## Part 1: shared code

**Why is `CartLine` immutable with `copyWith`? Which styles would still "work" with mutation, and why is it a trap?**
Riverpod, Cubit and Bloc decide whether to notify by comparing the new state with the old one (`==`). If you mutate the list in place and hand back the same object, old and new are the same instance, so the change is treated as "nothing happened" and the UI never updates. Only `setState` would still appear to work, because it does not compare anything: it just re-runs `build`. That is the trap: code that works under `setState` silently breaks the moment it moves to another style. Mutation also breaks undo (history snapshots would alias the live state) and `select` / `buildWhen` (they compare projections of old and new).

**Why does `CartBody` take callbacks instead of importing a provider or bloc?**
So it knows nothing about state management. The same widget is reused by all four pages, it can be tested without any provider or bloc, and the only thing that changes between folders is how state is held and subscribed to.

## Part 2: setState

**After T4, how would a second page (order history) read the cart?** It could not. `_state` is a field of one `State` object, so it is private to that page and is destroyed when the page is popped. I would have to lift the state to a common ancestor (the home page or an `InheritedWidget` / `ValueNotifier`) and pass it down and up through constructors, which is effectively adopting another state-management style.

**After T5, where does `_history` live, and what happens on hot restart vs hot reload?** It is a field on the same `State` object. Hot reload keeps the `State` object, so cart and history survive. Hot restart rebuilds the app from `main`, creating a fresh `State`, so both are empty. Popping the page also drops them.

**T3: why is storing `total` a bug waiting to happen?** A stored `total` is a second copy of information that is already determined by `lines` and `coupon`. Any code path that changes lines or the coupon and forgets to update `total` leaves the UI showing a wrong amount. As a getter it is recomputed from the source of truth and cannot go stale.

**T4: what happens without `if (!mounted) return;`?** If the user leaves the page while the 1.5 s request is running, the `await` still completes and the code calls `setState` (and uses `context` for the SnackBar) on a `State` that was disposed. In debug this throws the "setState() called after dispose()" error, and using the context would target a widget that is no longer in the tree.

**T6:** most of the widget test is about finding and driving widgets (`find.byType(ActionChip)`, `enterText`, `tap`, `pump`); the cart logic being verified is one line at the end (`88.20`).

## Part 3: Riverpod

**Where did I use `ref.read` and `ref.watch`, and why?**
- `ref.watch(cartProvider)` in the page `build`: display data, must rebuild on change.
- `ref.watch(canUndoProvider)` in the page `build`: the Undo button must rebuild when availability changes.
- `ref.watch(cartProvider.select((s) => s.summary))` in the summary card: rebuild only when the summary values change.
- `ref.watch(cartProvider)` inside `canUndoProvider`: the history is a plain field, so the only signal that it may have changed is the cart state changing.
- `ref.read(cartProvider.notifier)` in the page `build`: a one-off handle to call methods, no subscription needed.
- `ref.read(cartProvider)` inside the `ref.listen` callback: read the current `orderId` / error at the moment of the event, inside a callback, so no subscription.
- `ref.read(cartProvider.notifier)` inside `canUndoProvider`: read the plain `canUndo` getter without subscribing to the notifier object.
- `ref.read(checkoutApiProvider)` inside `checkout()`: a one-off lookup in a method, never `watch` in a method.

**Why does the summary card rebuild less often than in the setState version?** In the setState version the card is rebuilt on every `setState` of the page, including ones that change nothing it displays (for example applying an invalid coupon only changes the error text). In Riverpod the card is a `const` widget that watches `select((s) => s.summary)`: a parent rebuild skips it, and its own subscription fires only when item count, subtotal, discount or total change (a record, which has value equality). Watch the `[Riverpod] SummaryView rebuilt` vs `[setState] SummaryView rebuilt` lines in the console.

**T2:** without `==` / `hashCode` on `CartState`, `copyWith(coupon: sameCode)` creates a new object that is never `==` to the old one, so listeners are notified on every apply. With value equality the repeated apply is skipped (and I also skip recording it in the undo history).

**T4: why is no `mounted` check needed?** The provider's state lives in the `ProviderContainer` owned by the root `ProviderScope`, not in the page. `cartProvider` is not `autoDispose`, so it outlives the page and setting `state` after the page is popped is safe. (If it were `autoDispose` and nothing listened any more, the notifier would be disposed mid-checkout and I would need `ref.mounted`.)

**T5: what happens with `autoDispose`?** Once the page is popped nothing listens to the provider, so Riverpod disposes it; coming back creates a new notifier with an empty cart and an empty `_history`. The history was a field of the notifier instance, so it dies with it.

## Part 4: Cubit

**What breaks if `BlocProvider` is inside `CartBody`?** `BlocProvider` only exposes the cubit to the widgets *below* it. The AppBar undo button, the `BlocListener` for checkout feedback and anything else outside `CartBody` would throw `ProviderNotFoundException` on `context.read<CartCubit>()`. It would also make `CartBody` depend on a specific style, losing its "dumb UI" property.

**Riverpod equivalents:**
| Cubit / Bloc | Riverpod |
|---|---|
| `BlocProvider` | `ProviderScope` plus a provider definition (`NotifierProvider`); scoping with a nested `ProviderScope` / overrides |
| `BlocBuilder` | `ref.watch` in a `ConsumerWidget` / `Consumer` |
| `BlocListener` | `ref.listen` |
| `context.read` | `ref.read` |
| `buildWhen` / `BlocSelector` | `ref.watch(provider.select(...))` |

**T2: dropped emit.** Applying `SAVE10` twice: the second time `next == state`, so `emit` is skipped. The cubit also checks this before pushing history so a dropped emit does not leave a useless undo step. The `[change]` lines from `AppBlocObserver` show only one change.

**T5: why was `canUndo` folded into the state?** A getter on the cubit is not observable: `BlocBuilder` only rebuilds when a new state is emitted. So `canUndo` is a field of `CartState`, set on every mutation and recomputed on undo.

**T4: emit after `close()`.** It throws a `StateError`. `BlocProvider` closes the cubit when the page is disposed, so `checkout()` checks `isClosed` after the `await`.

## Part 5: Bloc

**When is the event layer worth its boilerplate?** Clearly better than a Cubit: checkout. Event transformers (`droppable()` here, but also `restartable`, `debounce`) declare concurrency behaviour, and `onTransition` logs `state --event--> state`. Pure overhead: the quantity stepper or applying a coupon. They are synchronous pure transitions, so an event class plus a handler is just a method call with more ceremony.

**Which styles can "drop duplicate taps" declaratively, and how do the others do it?** Only Bloc (`transformer: droppable()`). Cubit and Riverpod guard by hand (`if (state.status == submitting) return;`, which is what this repo does). With `setState` the same guard on `_state.status` plus disabling the button. The UI also disables the button while submitting in all four.

**T5: which events are undoable?** Product added, quantity changed and coupon applied push history; checkout and undo do not. `CartEventUndo.isUndoable` is an exhaustive switch over the sealed events, so a new event cannot be added without deciding.

**What extra info does the Bloc log give?** The event that caused each change (`CartProductAdded`, `CartCouponApplied`, ...). A Cubit `onChange` only shows `state -> state`.

## Checkpoint questions

1. **Where state lives / when it dies.**
   - setState: in the `State` object; dies when the page leaves the tree (and on hot restart).
   - Riverpod: in the `ProviderContainer` of the root `ProviderScope`; dies when the scope is disposed (app end), or earlier if the provider is `autoDispose` and has no listeners, or on `invalidate`.
   - Cubit: in the cubit instance owned by `BlocProvider`; dies when that provider is disposed (page popped), which calls `close()`.
   - Bloc: same as Cubit.
2. **Single public mutation API.** Riverpod `Notifier`: its public methods (`add`, `checkout`, ...), which assign `state`. Cubit: its public methods, which call `emit`. Bloc: only `add(event)`. `setState` has no state holder, so no such API: the `State` object's own methods.
3. **Mapping.** `ref.watch` ↔ `BlocBuilder` (or `context.watch`); `ref.read` ↔ `context.read`; `ref.listen` ↔ `BlocListener`. `setState` is the baseline: it combines mutate and notify in one call and has no subscription; the whole `build` re-runs and passes data down by constructor.
4. **Why skip equal states, and what must `CartState` do?** Skipping avoids pointless rebuilds and listener calls when nothing changed. For that to be correct, `CartState` must (1) be immutable (always produce a new object via `copyWith`) and (2) implement value equality (`==` and `hashCode`, including element-wise equality of `lines`), otherwise equal states compare unequal (extra rebuilds) or mutated states compare equal (missed updates).
5. **Guard after `await`.** setState: `mounted` (the `State` can be disposed). Riverpod: nothing, because the non-`autoDispose` provider outlives the page. Cubit: `isClosed`, since `BlocProvider` closes the cubit on dispose and `emit` after close throws. Bloc: `emit.isDone`, since the handler's `emit` becomes unusable once the bloc is closed. They differ because the state lives in different owners with different lifetimes.

## Comparison table

Numbers are non-blank, non-comment lines measured on the final code. T1–T5 are implemented together on top of shared code, so they cannot be separated; "LOC" is the whole feature (state holder plus its page). The shared model is 141 LOC and the shared widgets 185 LOC, identical for all four.

| | setState | Riverpod | Cubit | Bloc |
|---|---|---|---|---|
| LOC, T1–T5 (holder + page) | 73 | 98 (44 + 54) | 102 (35 + 67) | 139 (29 + 39 + 71) |
| LOC, test code | 16 | 32 | 40 | 56 |
| Files | 1 | 2 | 2 | 3 (+1 observer) |
| Strength | Least code and no new concepts | State outside the widget tree, readable anywhere, unit-testable with no widgets | Simple methods, scoped provider, easy sequence assertions with `blocTest` | Every change is a named event: traceable, declarative concurrency (`droppable`) |
| Weakness | State dies with the page, cannot be shared, tests drive widgets | Must know `read` vs `watch` vs `listen`; lifetime rules (`autoDispose`) | `canUndo`-style derived info must live in state; no event trail | Most boilerplate; events are overhead for simple synchronous changes |

## Not done

- Stretch goals (optional, the 60-point maximum is reachable without them).
- Tags `p1-shared` ... `p5-bloc`, `flutter analyze` / `flutter test` runs, instructor demo and the screen recording must be done on your machine.
