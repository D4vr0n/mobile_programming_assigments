import 'package:bloc_test/bloc_test.dart';
import 'package:cart_four_ways/bloc/cart_bloc.dart';
import 'package:cart_four_ways/bloc/cart_event.dart';
import 'package:cart_four_ways/models/cart.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

import 'mocks.dart';

void main() {
  final keyboard = catalog.first;
  late MockCheckoutApi api;

  setUp(() => api = MockCheckoutApi());

  blocTest<CartBloc, CartState>(
    'add, add, SAVE10 emits exactly three states',
    build: () => CartBloc(api),
    act: (b) => b
      ..add(CartProductAdded(keyboard))
      ..add(CartProductAdded(keyboard))
      ..add(const CartCouponApplied('SAVE10')),
    expect: () => [
      isA<CartState>().having((s) => s.itemCount, 'itemCount', 1),
      isA<CartState>().having((s) => s.itemCount, 'itemCount', 2),
      isA<CartState>().having((s) => s.total, 'total', closeTo(88.2, 0.001)),
    ],
  );

  blocTest<CartBloc, CartState>(
    'failed checkout emits submitting then failure',
    setUp: () => stubCheckoutFails(api),
    build: () => CartBloc(api),
    act: (b) => b
      ..add(CartProductAdded(keyboard))
      ..add(const CartCheckoutRequested()),
    wait: const Duration(milliseconds: 50),
    skip: 1, // the state emitted by CartProductAdded
    expect: () => [
      isA<CartState>().having((s) => s.status, 'status', CheckoutStatus.submitting),
      isA<CartState>()
          .having((s) => s.status, 'status', CheckoutStatus.failure)
          .having((s) => s.lines, 'lines', isNotEmpty),
    ],
  );

  blocTest<CartBloc, CartState>(
    'droppable: two checkout requests emit one submitting state',
    setUp: () => stubCheckoutSucceeds(api),
    build: () => CartBloc(api),
    seed: () => CartState(lines: [CartLine(product: keyboard, qty: 1)]),
    act: (b) => b
      ..add(const CartCheckoutRequested())
      ..add(const CartCheckoutRequested()),
    wait: const Duration(milliseconds: 50),
    expect: () => [
      isA<CartState>().having((s) => s.status, 'status', CheckoutStatus.submitting),
      isA<CartState>().having((s) => s.status, 'status', CheckoutStatus.success),
    ],
    verify: (_) => verify(() => api.submit(any())).called(1),
  );
}
