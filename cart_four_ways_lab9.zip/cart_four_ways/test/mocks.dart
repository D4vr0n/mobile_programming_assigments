import 'package:cart_four_ways/services/checkout_api.dart';
import 'package:mocktail/mocktail.dart';

class MockCheckoutApi extends Mock implements CheckoutApi {}

/// Makes the mock behave like the real API does for totals above 500.
void stubCheckoutFails(MockCheckoutApi api) {
  registerFallbackValue(0.0);
  when(() => api.submit(any())).thenAnswer((_) async => throw const CheckoutException('Card declined'));
}

void stubCheckoutSucceeds(MockCheckoutApi api, [String orderId = 'ORD-1']) {
  registerFallbackValue(0.0);
  when(() => api.submit(any())).thenAnswer((_) async => orderId);
}
