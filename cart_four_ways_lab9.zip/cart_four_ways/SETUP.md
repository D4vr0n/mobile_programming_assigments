# Setup

```bash
flutter create cart_four_ways --empty
cd cart_four_ways
flutter pub add flutter_riverpod flutter_bloc bloc bloc_concurrency
flutter pub add --dev bloc_test mocktail
```

Then copy `lib/`, `test/`, `NOTES.md` from this folder over the generated project
(replace the generated `lib/main.dart` and delete the generated `test/widget_test.dart`), and run:

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

The project name must stay `cart_four_ways` because the tests import `package:cart_four_ways/...`.
`bloc_concurrency` is needed for `droppable()` (Part 5, T4).
