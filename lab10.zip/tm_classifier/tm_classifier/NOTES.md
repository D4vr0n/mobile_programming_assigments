# Lab 10 notes: Teachable Machine image classifier in Flutter

**Student:** Davron [[FILL IN: surname]]
**Partner:** [[FILL IN: partner's name]]
**Sessions:** Monday 16 November 2026 and Thursday 19 November 2026
**Repo / tags:** `p1-model`, `p2-setup`, `p3-classifier`, `p4-screens`, `p5-sources`

> Anything written as `[[FILL IN: ...]]` is something only the two of us can know (our own samples, our own phone, our own numbers). Search the file for `FILL IN` before handing it in; there should be none left.

---

## Part 1: Train and export the model

### T1: Class list

One of the classes is the background class (empty desk, no object).

| # | Label in labels.txt | What it is | Background class? |
|---|---------------------|------------|-------------------|
| 0 | [[FILL IN]] | | |
| 1 | [[FILL IN]] | | |
| 2 | [[FILL IN]] | | |
| 3 | [[FILL IN]] | | |
| 4 | [[FILL IN]] | | |
| 5 | [[FILL IN: e.g. Nothing]] | empty desk | yes |

### T2 to T5: What we did

- Project type: Image Project, Standard image model, six classes, each renamed so the label is the name the app shows.
- Samples per class: [[FILL IN: e.g. 60 / 55 / 62 / 58 / 60 / 70]]. We changed distance, angle, background and lighting, and both of us held the objects.
- Result in the Preview panel on a fresh position, per class: [[FILL IN: e.g. Mug 97 %, Bottle 91 %, ...]]. All six were at 80 % or more [[FILL IN: or say which class needed more samples and a retrain]].
- Screenshot of the preview with its bars: `docs/preview.png`.
- Export: Tensorflow Lite tab, Floating point. `converted_tflite.zip` contained `model_unquant.tflite` and `labels.txt`. `labels.txt` has one line per class in the form `0 Mug`. I also downloaded the project file so we can retrain without recording everything again.

### Questions

**What does the model answer when it sees an object that belongs to none of your classes? How does the background class change that?**

It still answers with one of our classes. The last layer is a softmax, which spreads 100 % over the classes the model knows about and has no "none of the above" slot. So a shoe, which we never trained on, is pushed onto whichever class looks most like it to the network, and the confidence can be surprisingly high. The background class gives the model one honest place to put "nothing I know here". With it, an empty desk or a blank wall ends up as the background class instead of being forced onto a random object. It helps most when the background samples also contain clutter that is not one of our objects. It does not make the model able to say "I have never seen this"; it only gives it one more thing to be.

**Floating point vs Quantized: what differs in file size, input type and Dart code?**

- *Size:* the quantized file stores its weights as 8-bit integers instead of 32-bit floats, so it is roughly a quarter of the size. Ours: floating point [[FILL IN: size]], and if we exported the quantized one too, [[FILL IN: size or "not exported"]].
- *Input type:* the floating point model takes `float32` values between -1 and 1. The quantized model takes `uint8` values from 0 to 255.
- *Dart code:* with the quantized model there is no `value / 127.5 - 1` step; the pixel values go in as they are, as integers. The output also comes back as `uint8`, so it has to be divided by 255 to get a probability. The input and output buffers have to be integer lists instead of `double` lists.

---

## Part 2: New project, assets and dependencies

- Project created with `flutter create tm_classifier --empty`. The folder `assets/model/` sits at the project root next to `lib`, and holds `model_unquant.tflite` and `labels.txt`.
- `pubspec.yaml` declares `assets/model/` under `flutter:` and has `tflite_flutter`, `image_picker`, `image` and `http` under `dependencies:` (not `dev_dependencies:`).
- iOS: added `NSCameraUsageDescription` and `NSPhotoLibraryUsageDescription` to `ios/Runner/Info.plist`, one plain sentence each. Android: added the `INTERNET` permission to `AndroidManifest.xml`, because release builds do not get it automatically and the download feature needs it.
- minSdk: [[FILL IN: "no error" or "Gradle asked for minSdk N, so I changed it to N"]].

### Questions

**What is the difference between listing `assets/model/` and listing `assets/`? Which files would each one bundle?**

Listing `assets/model/` bundles the files that sit directly in that folder: `model_unquant.tflite`, `labels.txt` (and `sample.jpg` if it is there). Listing `assets/` bundles only the files that sit directly in `assets/`. The entry is not recursive, so it does not go into the `model` subfolder, which means our two files would not be bundled at all and `Interpreter.fromAsset` would fail with "unable to load asset". To use the shorter line we would have to move the files up one level, or list the subfolder as well.

**Why can `image` and `http` run in a plain Dart unit test while `tflite_flutter` and `image_picker` cannot?**

`image` and `http` are written in pure Dart. They only need the Dart VM, which is what `flutter test` runs on. `tflite_flutter` loads the native TensorFlow Lite library through FFI, and `image_picker` talks to Android or iOS through a platform channel to open the camera or the gallery. Neither the native library nor a phone operating system exists inside a unit test. That is also why `parseLabels` lives in `lib/services/labels.dart` with no imports, and why the download code is tested with a fake `http` client (`test/downloader_test.dart`).

---

## Part 3: The classifier

### T10: Smoke test

`runSmokeTest` in `lib/services/smoke_test.dart` classifies `assets/model/sample.jpg` at start-up in debug mode and prints every label. Console output:

```
[[FILL IN: paste the [smoke] lines from the console]]
```

It had as many lines as classes, the right label ([[FILL IN: label]]) was on top, and the confidences added up to [[FILL IN: e.g. 1.0000]].

### T11: Load once, share everywhere

I went with **constructor injection**. `main.dart` creates one `AppController` and calls `init()`, which loads the classifier a single time. That controller is passed down through constructors (`WelcomeScreen` → `AppShell` → `HomeScreen`, `HistoryScreen`, `ModelScreen`). The Welcome screen shows a loading state until it is ready. `Classifier.load()` is only called inside the controller. `close()` is called when the controller is disposed, which happens when the app widget goes away or the app is detached; `close()` can be called twice without harm.

### T12: Fail politely

- *Bytes of a text file:* `classify` throws a `FormatException`. The Home screen catches it and shows "That file is not a picture I can read" in a banner. No red screen, and the spinner is switched off in a `finally` block, so it cannot freeze.
- *Typo in the model path:* `Classifier.load` wraps the error in a `ModelLoadException` that names the exact file and says to check `assets/model/` and `pubspec.yaml`. The Welcome screen shows that text with a "Try again" button. I tested it with [[FILL IN: what I changed, e.g. "model_unquant.tfl"]] and the screen said [[FILL IN: what it showed]].

### T13: Tests

`test/labels_test.dart` has the two tests the lab asks for: the normal case, and one with Windows line endings (`\r\n`), a blank last line and a label with a space (`2 Car keys`). The second one did not need a fix to the function, because `trim()` already removes the leftover `\r` and `replaceFirst` only cuts the leading number. `test/downloader_test.dart` has six more tests for the download messages. Result of `flutter test`: [[FILL IN: e.g. "All tests passed", 8 tests]].

### Questions

**Change the normalisation to `value / 255` and classify the sample again. What happens to the percentages, and why does nothing crash?**

The model was trained on values from -1 to 1. With `value / 255` every pixel lands between 0 and 1 instead, so the whole picture is squeezed into the top half of the range and looks washed out to the network. The percentages change and usually get less trustworthy: the top label can change or the confidence can drop or jump somewhere odd. On our sample: [[FILL IN: before → after, e.g. Mug 96.1 % → Bottle 54.3 %]]. Nothing crashes because the tensor still has exactly the shape and type the model asks for (`[1, 224, 224, 3]` floats). TensorFlow Lite checks shapes and types, not whether the values make sense. The output is still a softmax, so it still adds up to 1, which makes the wrong answer look perfectly normal. That is what the lab calls "confident nonsense".

**Where in the whole app is the number of classes written down? What would you have to edit after retraining with a seventh class?**

Nowhere, as a number. It comes from `labels.txt`: `parseLabels` gives a list, its length sizes the output buffer in `classify`, and the Welcome chips, the Result rows and the Model screen are all built by looping over the labels. The model file itself also has the count in its last layer, and `Classifier.load` compares the two and stops with a clear message if they disagree. After retraining with a seventh class I would replace `model_unquant.tflite` and `labels.txt` in `assets/model/` and change no Dart code. The only edits would be to these notes (class list and evaluation table).

---

## Part 4: Five screens, one design

### T14: Design credit

| | |
|---|---|
| Name | [[FILL IN]] |
| Author | [[FILL IN]] |
| Link | [[FILL IN]] |
| Licence | [[FILL IN]] |

The same four lines are in `lib/theme/design_credit.dart` and show on the Model screen. Reference frames: `docs/design-1.png`, `docs/design-2.png`.

### T15: Theme

Everything visual is in `lib/theme/app_theme.dart`: one `ThemeData` with a `ColorScheme`, a `TextTheme` and component themes for app bar, cards, buttons, inputs, chips, navigation bar and progress bars, plus the spacing and corner-radius constants. The screen files only use `Theme.of(context)` and those constants. There is no `Color(0xFF...)` and no font size number in any file under `lib/screens` or `lib/widgets`.

### T16 and T17: Screens

| # | Screen | File |
|---|--------|------|
| 1 | Welcome (also the loading screen) | `lib/screens/welcome_screen.dart` |
| 2 | Home | `lib/screens/home_screen.dart` |
| 3 | Result | `lib/screens/result_screen.dart` |
| 4 | History (with an empty state) | `lib/screens/history_screen.dart` |
| 5 | Model | `lib/screens/model_screen.dart` |

A bottom navigation bar (`lib/screens/app_shell.dart`) connects Home, History and Model; Result is pushed on top. Back works everywhere: from Result it pops, and on History or Model it goes back to Home before the app closes. Loading, empty and error states are designed (spinner on Welcome, empty History with a button, error banners on Home and Welcome). I checked for overflow stripes on a small phone: [[FILL IN: device or emulator size and result]].

### Questions

**Name two things in the Figma design that you changed or left out in Flutter, and why.**

1. [[FILL IN: e.g. "The design used a custom icon set; I used the Material icons that ship with Flutter so I did not have to add an asset package."]]
2. [[FILL IN: e.g. "The design had a profile tab; this app has no accounts, so I left it out."]]

**The Model screen shows the labels. Does it read them from the classifier or from the file again? Defend your choice.**

From the classifier. `Classifier.labels` is the list the model is really using to name its outputs, so the screen shows exactly what produces the results. If the screen read `labels.txt` again there would be two copies of the parsing and two places that could drift apart, plus an extra asset read for no reason. It also means that if loading fails the screen has nothing to show, which is honest: there is no model.

---

## Part 5: Three sources, one result

- **Camera and gallery** (`lib/services/image_sources.dart`): `image_picker` with `maxWidth: 1024`. A cancelled pick returns `null` and the app just stays where it is, with no error.
- **Download** (`lib/services/downloader.dart`): `http.get`, accepted only when the status is 200 and the content-type starts with `image/`. Wrong address format, no network or unreachable host, a 404 or other status, a web page instead of a picture, an empty body, a file over 15 MB and a timeout (15 s) each give their own message. A spinner overlay shows while it downloads.
- **One path:** all three go through `_run` in `home_screen.dart`: bytes, then `AppController.classify`, then the Result screen, and the controller adds the entry to History. The classification code exists once.
- **Result screen:** picture centred with `BoxFit.contain` and capped at half the screen height; one row per label (name, bar, `(confidence * 100).toStringAsFixed(1)` and `%`), sorted, top row emphasised; the page scrolls; the source is shown as a chip in the app bar. A small line at the bottom shows the total of all percentages and the inference time.
- **History:** every successful classification is added with thumbnail, top label, percentage and source icon. Tapping an entry opens the Result screen with the stored predictions, so the model does not run again.
- **Browser route:** I saved a picture from the phone's browser and classified it through the gallery: [[FILL IN: yes, and what it gave]].

### T23: Evaluation

Three new pictures per class, spread over camera, gallery and download. `Correct` is yes when the predicted label equals the expected one.

| # | Source | Expected | Predicted | % | Correct |
|---|--------|----------|-----------|---|---------|
| 1 | Camera | [[class 0]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 2 | Gallery | [[class 0]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 3 | Download | [[class 0]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 4 | Camera | [[class 1]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 5 | Gallery | [[class 1]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 6 | Download | [[class 1]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 7 | Camera | [[class 2]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 8 | Gallery | [[class 2]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 9 | Download | [[class 2]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 10 | Camera | [[class 3]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 11 | Gallery | [[class 3]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 12 | Download | [[class 3]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 13 | Camera | [[class 4]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 14 | Gallery | [[class 4]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 15 | Download | [[class 4]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 16 | Camera | [[class 5]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 17 | Gallery | [[class 5]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |
| 18 | Download | [[class 5]] | [[FILL IN]] | [[FILL IN]] | [[yes/no]] |

(Add three rows per extra class if you have more than six.)

**Overall accuracy:** [[FILL IN: correct]] correct out of [[FILL IN: attempts]] = [[FILL IN: %]]
**Weakest class:** [[FILL IN: class name, and what it was mistaken for]]

### Questions

**The same object scored differently from the camera and from a downloaded picture. Give two reasons that come from your training data rather than from your code.**

1. All our training pictures came from one laptop webcam in one room: same lens, same colour balance, same soft focus, same desk and lighting. A picture from the internet is usually a sharp studio shot on a clean background, and a phone photo has a different camera and different colours again. The model has only learned what our webcam saw, so anything that looks different from that gets a lower or a wrong score.
2. Our samples are not very varied. Each class was recorded in a few short bursts, so many of the 50 or so images are nearly the same frame, and they often include our hands and the same piece of desk. The model can end up partly recognising "my hand on this desk" instead of the object. And the object is one specific mug or pen of ours, while the downloaded picture shows a different one. A downloaded picture has none of the hands or the desk, so the score drops.

**`classify` runs on the UI thread. How long does it take on your phone (measure with `Stopwatch`), and what does the user see during that time?**

On [[FILL IN: phone model]] it takes about [[FILL IN: ms]] ms per picture (the app prints it as `[classify]` in the console and shows it under the percentages on the Result screen), measured over [[FILL IN: how many]] pictures. While it runs, the UI thread cannot draw or react to touches, so the spinner can stutter or stand still and taps do nothing until it finishes. To make sure the user at least sees "Classifying…" first, the controller waits 40 ms before it starts so Flutter can paint the overlay. Running the interpreter in an isolate (stretch goal 3) would keep the spinner moving.

---

## Stretch goals

[[FILL IN: "None attempted." or list the ones that work and were demonstrated.]]

---

## Checkpoint questions

**1. Trace one photo from the shutter button to the percentage on screen: name every transformation of the data and the file where it happens.**

1. Tap *Take a photo* on Home: `_run` in `lib/screens/home_screen.dart` calls `ImageSources.fromCamera`.
2. `lib/services/image_sources.dart`: `image_picker` opens the phone's camera app; it hands back a file already shrunk to at most 1024 px wide (JPEG), and `readAsBytes()` turns that file into a `Uint8List` of encoded JPEG bytes.
3. Back in `_run`, the bytes go to `AppController.classify` (`lib/services/app_controller.dart`), which starts a stopwatch and calls the classifier.
4. `Classifier.classify` (`lib/services/classifier.dart`):
   - `img.decodeImage`: encoded JPEG bytes to a pixel image.
   - `img.bakeOrientation`: applies the rotation stored in the EXIF data.
   - `img.copyResizeCropSquare`: centre crop to a square, resized to 224 × 224.
   - the pixel loop: each red, green and blue value (0 to 255) becomes `value / 127.5 - 1`, giving a nested list of shape `[1, 224, 224, 3]`.
   - `_interpreter.run`: TensorFlow Lite fills the output list of shape `[1, classes]` with probabilities.
   - pairing with the labels, then sorting highest first: a `List<Prediction>`.
5. `AppController.classify` wraps image bytes, predictions, source and timing in a `HistoryEntry` and inserts it at the top of the history.
6. `HomeScreen` pushes `ResultScreen` (`lib/screens/result_screen.dart`). `Image.memory` draws the picture and each `PredictionRow` (`lib/widgets/prediction_row.dart`) draws a bar and the text from `formatPercent`: `(confidence * 100).toStringAsFixed(1)` plus ` %`.

**2. Which three lines of `pubspec.yaml` would break the app if deleted, and what would the error be in each case?**

1. `- assets/model/` under `flutter: assets:`. The app still builds, but at start-up `Interpreter.fromAsset` cannot find the model and the Welcome screen shows the "Could not load assets/model/model_unquant.tflite" message (an "unable to load asset" error underneath).
2. `tflite_flutter: ^0.12.1`. The project does not compile: `flutter analyze` and the build report that the URI `package:tflite_flutter/tflite_flutter.dart` does not exist, and that `Interpreter` is not defined.
3. `image_picker: ^1.2.3`. Same kind of compile error in `image_sources.dart`: the URI `package:image_picker/image_picker.dart` does not exist, and `ImagePicker` and `ImageSource` are undefined. (Removing `image` or `http` fails in exactly the same way, in `classifier.dart` and `downloader.dart`.)

**3. Why must the pre-processing in Flutter match what Teachable Machine did during training? Name the two things that have to match.**

The network only ever learned from pictures prepared in one particular way, and it has no way to notice if it is fed something prepared differently. The two things that have to match are:

1. **The geometry:** a square centre crop resized to 224 × 224 (same crop, same size, and the right orientation).
2. **The value scaling:** each channel scaled to -1 to 1 with `value / 127.5 - 1` (and in the same red, green, blue order).

If either is off, the app still runs and still prints percentages, but they are nonsense.

**4. Your model is 97 % sure that a shoe is a mug. Is that a bug? What does a percentage from this model mean, and what does it not mean?**

Not a bug in the code; it is how this kind of model behaves. The percentages are softmax outputs: they say how the model splits 100 % between the classes it knows, based on how much the picture resembles our training samples. 97 % for Mug means "of my six classes, Mug looks by far the most like this picture". It does not mean there is a 97 % chance it is a mug, because the model was never taught that "something else" exists, and the numbers are not calibrated against real accuracy. A shoe forced into six wrong boxes still produces a confident-looking answer. To improve it we would add an "other objects" class, record more varied samples (including shoes), or only show a result above a confidence threshold and otherwise say "not sure".

**5. What stays on the device and what leaves it in this app? Compare with sending the photo to a cloud vision API.**

Everything stays on the device: the photo, the model file, the labels, the predictions and the history. The classification happens inside the app with no server. The only thing that crosses the network is the download feature, where the address I type is sent to that website and the picture comes in (nothing of ours goes out). That is the only reason the app needs the `INTERNET` permission; camera and gallery do not.

With a cloud vision API, every photo would be uploaded to someone else's server, so it needs a connection, adds delay, may cost money per request and raises privacy questions (who stores the picture, and for how long). In exchange the cloud model is far bigger, knows thousands of things without us recording samples, and can be improved without shipping a new app. On-device gives privacy, offline use and instant answers, but only for the small set of classes we trained and an app update when we change them.
