import 'package:flutter_test/flutter_test.dart';
import 'package:tm_classifier/services/labels.dart';

void main() {
  test('parseLabels turns the exported labels.txt into plain names', () {
    expect(parseLabels('0 Mug\n1 Bottle\n'), ['Mug', 'Bottle']);
  });

  test(
    'parseLabels copes with Windows line endings, a blank last line and '
    'a label that contains a space',
    () {
      expect(
        parseLabels('0 Mug\r\n1 Bottle\r\n2 Car keys\r\n\r\n'),
        ['Mug', 'Bottle', 'Car keys'],
      );
    },
  );
}
