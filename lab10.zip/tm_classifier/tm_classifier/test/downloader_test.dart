import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:tm_classifier/services/downloader.dart';

/// These run as plain Dart tests: http has no native code, so a fake client
/// is enough to check every message T20 asks for.
void main() {
  final pngBytes = Uint8List.fromList([137, 80, 78, 71, 13, 10, 26, 10]);

  test('returns the bytes when the status is 200 and the type is image/*', () async {
    final client = MockClient(
      (request) async => http.Response.bytes(
        pngBytes,
        200,
        headers: {'content-type': 'image/png'},
      ),
    );
    expect(await downloadImage('https://example.com/a.png', client: client), pngBytes);
  });

  test('a 404 gives a message with the status code', () async {
    final client = MockClient((request) async => http.Response('nope', 404));
    await expectLater(
      downloadImage('https://example.com/missing.png', client: client),
      throwsA(
        isA<ImageSourceException>().having((e) => e.message, 'message', contains('404')),
      ),
    );
  });

  test('a web page instead of a picture is refused', () async {
    final client = MockClient(
      (request) async => http.Response(
        '<html></html>',
        200,
        headers: {'content-type': 'text/html; charset=utf-8'},
      ),
    );
    await expectLater(
      downloadImage('https://example.com/page', client: client),
      throwsA(
        isA<ImageSourceException>().having((e) => e.message, 'message', contains('text/html')),
      ),
    );
  });

  test('no network gives a clear message', () async {
    final client = MockClient(
      (request) async => throw http.ClientException('Failed host lookup'),
    );
    await expectLater(
      downloadImage('https://example.com/a.png', client: client),
      throwsA(
        isA<ImageSourceException>().having((e) => e.message, 'message', contains('Could not reach')),
      ),
    );
  });

  test('a slow server ends in a timeout message', () async {
    final client = MockClient((request) async {
      await Future<void>.delayed(const Duration(milliseconds: 300));
      return http.Response('late', 200);
    });
    await expectLater(
      downloadImage(
        'https://example.com/a.png',
        client: client,
        timeout: const Duration(milliseconds: 20),
      ),
      throwsA(
        isA<ImageSourceException>().having((e) => e.message, 'message', contains('too long')),
      ),
    );
  });

  test('something that is not a web address is refused before any request', () async {
    await expectLater(
      downloadImage('hello world'),
      throwsA(isA<ImageSourceException>()),
    );
  });
}
