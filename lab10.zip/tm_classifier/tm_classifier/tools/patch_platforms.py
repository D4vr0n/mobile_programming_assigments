#!/usr/bin/env python3
"""T9: platform settings the app needs.

Run once from the project root, after `flutter create`:

    python3 tools/patch_platforms.py

iOS:     adds NSCameraUsageDescription and NSPhotoLibraryUsageDescription
Android: adds the INTERNET permission (release builds do not have it by default)

Safe to run twice; it skips anything that is already there.
"""
from pathlib import Path

PLIST = Path("ios/Runner/Info.plist")
MANIFEST = Path("android/app/src/main/AndroidManifest.xml")

PLIST_KEYS = {
    "NSCameraUsageDescription": (
        "ThingSpotter uses the camera so you can photograph an object and "
        "find out what it is."
    ),
    "NSPhotoLibraryUsageDescription": (
        "ThingSpotter reads the picture you choose from your library so it "
        "can tell you what is in it."
    ),
}
PERMISSION = '<uses-permission android:name="android.permission.INTERNET"/>'


def patch_plist() -> None:
    if not PLIST.exists():
        print(f"skip: {PLIST} not found (no iOS folder?)")
        return
    text = PLIST.read_text(encoding="utf-8")
    add = ""
    for key, sentence in PLIST_KEYS.items():
        if key not in text:
            add += f"\t<key>{key}</key>\n\t<string>{sentence}</string>\n"
    if not add:
        print("iOS: already patched")
        return
    end = text.rfind("</dict>")  # the closing tag of the top-level dict
    PLIST.write_text(text[:end] + add + text[end:], encoding="utf-8")
    print("iOS: added camera and photo library descriptions")


def patch_manifest() -> None:
    if not MANIFEST.exists():
        print(f"skip: {MANIFEST} not found (no Android folder?)")
        return
    text = MANIFEST.read_text(encoding="utf-8")
    if "android.permission.INTERNET" in text:
        print("Android: INTERNET permission already there")
        return
    start = text.index("<application")
    patched = text[:start] + PERMISSION + "\n    " + text[start:]
    MANIFEST.write_text(patched, encoding="utf-8")
    print("Android: added INTERNET permission")


if __name__ == "__main__":
    patch_plist()
    patch_manifest()
