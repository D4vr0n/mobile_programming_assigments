/// Name and one-line pitch, shown on the Welcome screen and in the app bar.
const appName = 'ThingSpotter';
const appTagline =
    'Point your phone at one of my trained objects and it names it in a blink. '
    'Everything runs on the device, no internet needed.';
