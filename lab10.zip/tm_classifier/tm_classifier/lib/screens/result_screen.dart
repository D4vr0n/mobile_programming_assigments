import 'package:flutter/material.dart';

import '../models/history_entry.dart';
import '../theme/app_theme.dart';
import '../widgets/prediction_row.dart';

/// Screen 3. The same widget for camera, gallery and download, and for entries
/// reopened from History (it only displays; it never runs the model).
class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.entry});

  final HistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final maxImageHeight = MediaQuery.sizeOf(context).height * 0.5;
    final total = entry.predictions.fold<double>(0, (sum, p) => sum + p.confidence);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Result'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: AppSpacing.m),
            child: Chip(
              avatar: Icon(entry.source.icon, size: 18),
              label: Text(entry.source.label),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.m),
          children: [
            // 1. The picture, centred, never cropped, at most half the screen.
            Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: maxImageHeight),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(AppRadius.medium),
                  child: Image.memory(
                    entry.bytes,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stack) => Container(
                      height: 160,
                      alignment: Alignment.center,
                      color: scheme.surfaceContainerHighest,
                      child: const Icon(Icons.broken_image_outlined, size: 40),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.l),
            // 2-4. One row per label, highest first, top row emphasised.
            for (var i = 0; i < entry.predictions.length; i++) ...[
              PredictionRow(
                prediction: entry.predictions[i],
                highlighted: i == 0,
              ),
              const SizedBox(height: AppSpacing.xs),
            ],
            const SizedBox(height: AppSpacing.s),
            Text(
              'Total ${(total * 100).toStringAsFixed(1)} % · '
              'classified on this phone in ${entry.inferenceMs} ms',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
