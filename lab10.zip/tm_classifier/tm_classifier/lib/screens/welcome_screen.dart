import 'package:flutter/material.dart';

import '../app_info.dart';
import '../services/app_controller.dart';
import '../services/image_sources.dart';
import '../theme/app_theme.dart';
import '../widgets/error_banner.dart';
import 'app_shell.dart';

/// Screen 1. Also the loading screen: the model loads while it is showing, and
/// Get started stays disabled until the classifier is ready.
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({
    super.key,
    required this.controller,
    required this.sources,
  });

  final AppController controller;
  final ImageSources sources;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            return Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(AppSpacing.l),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: AppSpacing.xl),
                        Container(
                          padding: const EdgeInsets.all(AppSpacing.m),
                          decoration: BoxDecoration(
                            color: scheme.primaryContainer,
                            borderRadius: BorderRadius.circular(AppRadius.large),
                          ),
                          child: Icon(
                            Icons.center_focus_strong_outlined,
                            size: 40,
                            color: scheme.onPrimaryContainer,
                          ),
                        ),
                        const SizedBox(height: AppSpacing.l),
                        Text(appName, style: theme.textTheme.displaySmall),
                        const SizedBox(height: AppSpacing.s),
                        Text(appTagline, style: theme.textTheme.bodyLarge),
                        const SizedBox(height: AppSpacing.xl),
                        _status(context),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.l),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: controller.isReady
                          ? () => Navigator.of(context).pushReplacement(
                                MaterialPageRoute<void>(
                                  builder: (_) => AppShell(
                                    controller: controller,
                                    sources: sources,
                                  ),
                                ),
                              )
                          : null,
                      child: const Text('Get started'),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Loading, error or the list of classes, depending on the model's state.
  Widget _status(BuildContext context) {
    final theme = Theme.of(context);

    if (controller.isLoading) {
      return Row(
        children: [
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(strokeWidth: 3),
          ),
          const SizedBox(width: AppSpacing.m),
          Text('Loading the model…', style: theme.textTheme.bodyLarge),
        ],
      );
    }

    final error = controller.loadError;
    if (error != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ErrorBanner(message: error),
          const SizedBox(height: AppSpacing.m),
          OutlinedButton.icon(
            onPressed: controller.init,
            icon: const Icon(Icons.refresh),
            label: const Text('Try again'),
          ),
        ],
      );
    }

    final labels = controller.classifier?.labels ?? const <String>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('I can recognise', style: theme.textTheme.titleMedium),
        const SizedBox(height: AppSpacing.s + AppSpacing.xs),
        Wrap(
          spacing: AppSpacing.s,
          runSpacing: AppSpacing.s,
          children: [for (final label in labels) Chip(label: Text(label))],
        ),
      ],
    );
  }
}
