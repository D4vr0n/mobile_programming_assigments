import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../app_info.dart';
import '../models/history_entry.dart';
import '../services/app_controller.dart';
import '../services/image_sources.dart';
import '../theme/app_theme.dart';
import '../widgets/action_card.dart';
import '../widgets/busy_overlay.dart';
import '../widgets/download_dialog.dart';
import '../widgets/entry_tile.dart';
import '../widgets/error_banner.dart';
import 'result_screen.dart';

/// Screen 2. Three actions, one shared path behind them.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.controller, required this.sources});

  final AppController controller;
  final ImageSources sources;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _busy; // text for the overlay, null when idle
  String? _error; // text for the error banner, null when fine

  /// The one path for all three sources: bytes -> classify -> Result -> History.
  /// Only the way the bytes arrive (getBytes) differs between the buttons.
  Future<void> _run(
    Future<Uint8List?> Function() getBytes,
    SourceKind kind, {
    String? fetching,
  }) async {
    setState(() {
      _error = null;
      _busy = fetching;
    });
    try {
      final bytes = await getBytes();
      if (bytes == null) return; // the user backed out: not an error
      if (!mounted) return;

      setState(() => _busy = 'Classifying…');
      final entry = await widget.controller.classify(bytes, kind);
      if (!mounted) return;

      setState(() => _busy = null);
      await Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => ResultScreen(entry: entry)),
      );
    } on ImageSourceException catch (e) {
      _fail(e.message);
    } on FormatException {
      _fail(
        'That file is not a picture I can read. Try a JPG or PNG image.',
      );
    } catch (e) {
      _fail('Something went wrong while classifying: $e');
    } finally {
      if (mounted && _busy != null) setState(() => _busy = null);
    }
  }

  void _fail(String message) {
    if (mounted) setState(() => _error = message);
  }

  Future<void> _download() async {
    final url = await showDialog<String>(
      context: context,
      builder: (_) => const DownloadDialog(),
    );
    if (url == null || !mounted) return;
    await _run(
      () => widget.sources.fromUrl(url),
      SourceKind.download,
      fetching: 'Downloading the picture…',
    );
  }

  void _openResult(HistoryEntry entry) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => ResultScreen(entry: entry)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text(appName)),
      body: Stack(
        children: [
          SafeArea(
            child: ListenableBuilder(
              listenable: widget.controller,
              builder: (context, _) {
                final latest = widget.controller.latest;
                return ListView(
                  padding: const EdgeInsets.all(AppSpacing.m),
                  children: [
                    Text(
                      'What are we looking at?',
                      style: theme.textTheme.headlineSmall,
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Pick where the picture comes from.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.m),
                    if (_error != null) ...[
                      ErrorBanner(
                        message: _error!,
                        onDismiss: () => setState(() => _error = null),
                      ),
                      const SizedBox(height: AppSpacing.m),
                    ],
                    ActionCard(
                      icon: SourceKind.camera.icon,
                      title: 'Take a photo',
                      subtitle: 'Use the phone camera',
                      onTap: () => _run(widget.sources.fromCamera, SourceKind.camera),
                    ),
                    const SizedBox(height: AppSpacing.s + AppSpacing.xs),
                    ActionCard(
                      icon: SourceKind.gallery.icon,
                      title: 'Choose from gallery',
                      subtitle: 'Pick a picture you already have',
                      onTap: () => _run(widget.sources.fromGallery, SourceKind.gallery),
                    ),
                    const SizedBox(height: AppSpacing.s + AppSpacing.xs),
                    ActionCard(
                      icon: SourceKind.download.icon,
                      title: 'Download an image',
                      subtitle: 'Paste the address of a picture',
                      onTap: _download,
                    ),
                    const SizedBox(height: AppSpacing.l),
                    Text('Latest result', style: theme.textTheme.titleMedium),
                    const SizedBox(height: AppSpacing.s),
                    if (latest != null)
                      EntryTile(entry: latest, onTap: () => _openResult(latest))
                    else
                      Text(
                        'Nothing classified yet. Your first result will show up here.',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
          if (_busy != null) BusyOverlay(message: _busy!),
        ],
      ),
    );
  }
}
