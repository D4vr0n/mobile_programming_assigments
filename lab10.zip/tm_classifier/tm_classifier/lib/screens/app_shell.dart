import 'package:flutter/material.dart';

import '../services/app_controller.dart';
import '../services/image_sources.dart';
import 'history_screen.dart';
import 'home_screen.dart';
import 'model_screen.dart';

/// Bottom navigation for Home, History and Model. Result is pushed on top.
class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller, required this.sources});

  final AppController controller;
  final ImageSources sources;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    // Back on History or Model goes to Home first; only Home lets the app close.
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) setState(() => _index = 0);
      },
      child: Scaffold(
        body: IndexedStack(
          index: _index,
          children: [
            HomeScreen(controller: widget.controller, sources: widget.sources),
            HistoryScreen(
              controller: widget.controller,
              onGoHome: () => setState(() => _index = 0),
            ),
            ModelScreen(controller: widget.controller),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'Home',
            ),
            NavigationDestination(
              icon: Icon(Icons.history),
              selectedIcon: Icon(Icons.history),
              label: 'History',
            ),
            NavigationDestination(
              icon: Icon(Icons.memory_outlined),
              selectedIcon: Icon(Icons.memory),
              label: 'Model',
            ),
          ],
        ),
      ),
    );
  }
}
