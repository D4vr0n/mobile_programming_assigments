import 'package:flutter/material.dart';

import '../services/app_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import '../widgets/entry_tile.dart';
import 'result_screen.dart';

/// Screen 4. Everything classified in this session, newest first.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({
    super.key,
    required this.controller,
    required this.onGoHome,
  });

  final AppController controller;
  final VoidCallback onGoHome;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            final entries = controller.history;
            if (entries.isEmpty) {
              return EmptyState(
                icon: Icons.history,
                title: 'Nothing here yet',
                message:
                    'Pictures you classify in this session will be listed here, '
                    'newest first.',
                actionLabel: 'Classify a picture',
                onAction: onGoHome,
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(AppSpacing.m),
              itemCount: entries.length,
              separatorBuilder: (context, index) =>
                  const SizedBox(height: AppSpacing.s + AppSpacing.xs),
              itemBuilder: (context, index) {
                final entry = entries[index];
                // Reopens the stored result; the model is not run again.
                return EntryTile(
                  entry: entry,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => ResultScreen(entry: entry),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
