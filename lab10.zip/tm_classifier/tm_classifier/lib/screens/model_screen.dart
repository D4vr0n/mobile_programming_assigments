import 'package:flutter/material.dart';

import '../services/app_controller.dart';
import '../services/classifier.dart';
import '../theme/app_theme.dart';
import '../theme/design_credit.dart';

/// Screen 5. What the loaded model actually contains, plus the design credit.
/// The labels come from the Classifier instance, not from labels.txt again,
/// so this screen shows exactly what the model is using.
class ModelScreen extends StatelessWidget {
  const ModelScreen({super.key, required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Model')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            final classifier = controller.classifier;
            if (classifier == null) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(AppSpacing.l),
                  child: Text(
                    controller.loadError ?? 'The model is not loaded.',
                    style: theme.textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            return ListView(
              padding: const EdgeInsets.all(AppSpacing.m),
              children: [
                _Section(
                  title: 'Details',
                  children: [
                    _InfoRow('Classes', '${classifier.labels.length}'),
                    _InfoRow(
                      'Input size',
                      '${Classifier.inputSize} × ${Classifier.inputSize} px, RGB',
                    ),
                    _InfoRow('Input tensor', '${classifier.inputShape}'),
                    _InfoRow('Output tensor', '${classifier.outputShape}'),
                    _InfoRow('Model file', Classifier.defaultModelPath.split('/').last),
                    _InfoRow('Labels file', Classifier.defaultLabelsPath.split('/').last),
                  ],
                ),
                const SizedBox(height: AppSpacing.m),
                _Section(
                  title: 'Labels',
                  children: [
                    for (var i = 0; i < classifier.labels.length; i++)
                      _InfoRow('$i', classifier.labels[i]),
                  ],
                ),
                const SizedBox(height: AppSpacing.m),
                _Section(
                  title: 'Design credit',
                  children: [
                    _InfoRow('Design', designCredit.name),
                    _InfoRow('Author', designCredit.author),
                    _InfoRow('Link', designCredit.url),
                    _InfoRow('Licence', designCredit.licence),
                  ],
                ),
                const SizedBox(height: AppSpacing.m),
                Text(
                  'Everything on this screen was read from the loaded model. '
                  'No picture ever leaves the phone, except the one you ask to '
                  'download.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.m),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: AppSpacing.s),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow(this.name, this.value);

  final String name;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              name,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(child: Text(value, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}
