/// T14: credit for the Figma Community design the screens are based on.
///
/// Fill these four values in once you have picked a design. The Model screen
/// shows them, and the same four things go into NOTES.md.
class DesignCredit {
  const DesignCredit({
    required this.name,
    required this.author,
    required this.url,
    required this.licence,
  });

  final String name;
  final String author;
  final String url;
  final String licence;
}

const designCredit = DesignCredit(
  name: 'FILL IN: name of the Figma file',
  author: 'FILL IN: author',
  url: 'FILL IN: https://www.figma.com/community/file/...',
  licence: 'FILL IN: e.g. CC BY 4.0',
);
