import 'dart:typed_data';

import 'package:flutter/material.dart' show IconData, Icons;

import '../services/classifier.dart' show Prediction;

enum SourceKind {
  camera('Camera', Icons.photo_camera_outlined),
  gallery('Gallery', Icons.photo_library_outlined),
  download('Download', Icons.cloud_download_outlined);

  const SourceKind(this.label, this.icon);
  final String label;
  final IconData icon;
}

/// One finished classification. It keeps the predictions, so reopening it from
/// History shows the result without running the model again.
class HistoryEntry {
  const HistoryEntry({
    required this.bytes,
    required this.predictions,
    required this.source,
    required this.inferenceMs,
    required this.time,
  });

  final Uint8List bytes;
  final List<Prediction> predictions; // sorted, highest first
  final SourceKind source;
  final int inferenceMs;
  final DateTime time;

  Prediction get top => predictions.first;
}
