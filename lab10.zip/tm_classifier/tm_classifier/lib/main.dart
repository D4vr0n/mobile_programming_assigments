import 'package:flutter/material.dart';

import 'app_info.dart';
import 'screens/welcome_screen.dart';
import 'services/app_controller.dart';
import 'services/image_sources.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const TmApp());
}

class TmApp extends StatefulWidget {
  const TmApp({super.key});

  @override
  State<TmApp> createState() => _TmAppState();
}

class _TmAppState extends State<TmApp> with WidgetsBindingObserver {
  // The one and only Classifier lives inside this controller (T11).
  final _controller = AppController();
  final _sources = ImageSources();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller.init(); // the Welcome screen shows the loading state
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // The app is shutting down: release the interpreter.
    if (state == AppLifecycleState.detached) _controller.dispose();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose(); // closes the classifier; safe to reach twice
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appName,
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: WelcomeScreen(controller: _controller, sources: _sources),
    );
  }
}
