import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

import 'labels.dart';

export 'labels.dart' show parseLabels;

class Prediction {
  const Prediction(this.label, this.confidence);
  final String label;
  final double confidence; // 0.0 to 1.0
}

/// "73.4 %" - the one place a confidence is turned into text.
String formatPercent(double confidence) =>
    '${(confidence * 100).toStringAsFixed(1)} %';

/// Thrown by [Classifier.load] when the model or its labels cannot be used.
/// The message is written for a person: it names the file and says what to check.
class ModelLoadException implements Exception {
  ModelLoadException(this.path, this.cause);

  final String path;
  final Object cause;

  String get message =>
      'Could not load "$path".\n'
      'Check that the file is inside assets/model/ and that pubspec.yaml '
      'lists the folder under flutter: assets:.\n\n'
      'Details: $cause';

  @override
  String toString() => message;
}

/// Hides TensorFlow Lite from the rest of the app. Screens hand over image
/// bytes and get back a sorted list of labels with confidences.
class Classifier {
  Classifier._(this._interpreter, this.labels);

  static const defaultModelPath = 'assets/model/model_unquant.tflite';
  static const defaultLabelsPath = 'assets/model/labels.txt';
  static const inputSize = 224;

  final Interpreter _interpreter;
  final List<String> labels;
  bool _closed = false;

  /// Reads the model and the labels once. Slow, so call it once at start-up.
  static Future<Classifier> load({
    String modelPath = defaultModelPath,
    String labelsPath = defaultLabelsPath,
  }) async {
    final Interpreter interpreter;
    try {
      interpreter = await Interpreter.fromAsset(modelPath);
    } catch (e) {
      throw ModelLoadException(modelPath, e);
    }

    try {
      final String raw;
      try {
        raw = await rootBundle.loadString(labelsPath);
      } catch (e) {
        throw ModelLoadException(labelsPath, e);
      }
      final labels = parseLabels(raw);
      if (labels.isEmpty) {
        throw ModelLoadException(labelsPath, 'The file has no labels in it.');
      }

      // Fail early, with words, if the model and the labels do not belong together.
      final inShape = interpreter.getInputTensor(0).shape;
      if (inShape.length != 4 ||
          inShape[1] != inputSize ||
          inShape[2] != inputSize ||
          inShape[3] != 3) {
        throw ModelLoadException(
          modelPath,
          'Expected an input of [1, $inputSize, $inputSize, 3] but the model '
          'wants $inShape. Did you export the floating point TensorFlow Lite '
          'model from an Image Project?',
        );
      }
      final outShape = interpreter.getOutputTensor(0).shape;
      if (outShape.isEmpty || outShape.last != labels.length) {
        throw ModelLoadException(
          modelPath,
          'The model has ${outShape.isEmpty ? 0 : outShape.last} outputs but '
          '$labelsPath has ${labels.length} labels. Export both files from the '
          'same Teachable Machine project.',
        );
      }
      return Classifier._(interpreter, labels);
    } catch (_) {
      interpreter.close();
      rethrow;
    }
  }

  List<int> get inputShape => _interpreter.getInputTensor(0).shape;
  List<int> get outputShape => _interpreter.getOutputTensor(0).shape;

  /// Runs the model on encoded image bytes (jpg, png, ...).
  /// Throws a [FormatException] if the bytes are not a readable image.
  List<Prediction> classify(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw const FormatException('Not a readable image');

    // Same centre crop as in training. bakeOrientation applies the EXIF
    // rotation that phone cameras store, so a portrait photo is not sideways.
    final square = img.copyResizeCropSquare(
      img.bakeOrientation(decoded),
      size: inputSize,
    );

    // Input tensor, shape [1, 224, 224, 3], every value from -1 to 1.
    final input = [
      List.generate(
        inputSize,
        (y) => List.generate(inputSize, (x) {
          final p = square.getPixel(x, y);
          return [p.r / 127.5 - 1, p.g / 127.5 - 1, p.b / 127.5 - 1];
        }),
      ),
    ];

    // Output tensor, shape [1, classes], softmax probabilities.
    final output = [List<double>.filled(labels.length, 0)];
    _interpreter.run(input, output);

    // Pair first, sort second. Sorting the raw numbers first would shuffle
    // them away from their labels.
    return [
      for (var i = 0; i < labels.length; i++)
        Prediction(labels[i], output.first[i]),
    ]..sort((a, b) => b.confidence.compareTo(a.confidence));
  }

  void close() {
    if (_closed) return;
    _closed = true;
    _interpreter.close();
  }
}
