import 'dart:typed_data';

import 'package:flutter/services.dart' show PlatformException;
import 'package:image_picker/image_picker.dart';

import 'downloader.dart';

export 'downloader.dart' show ImageSourceException;

/// Camera, gallery and download differ only in how the bytes arrive. After
/// that, all three follow the same path (see HomeScreen._run).
class ImageSources {
  final _picker = ImagePicker();

  /// Opens the phone's camera. Returns null if the user backs out; that is
  /// not an error.
  Future<Uint8List?> fromCamera() => _pick(ImageSource.camera);

  /// Opens the gallery. Returns null if the user backs out.
  Future<Uint8List?> fromGallery() => _pick(ImageSource.gallery);

  Future<Uint8List> fromUrl(String url) => downloadImage(url);

  Future<Uint8List?> _pick(ImageSource source) async {
    try {
      // maxWidth shrinks a 12-megapixel photo before it reaches Dart. The
      // model only looks at 224 x 224 pixels, so full size would waste seconds.
      final shot = await _picker.pickImage(source: source, maxWidth: 1024);
      return shot == null ? null : await shot.readAsBytes();
    } on PlatformException catch (e) {
      final what = source == ImageSource.camera ? 'camera' : 'gallery';
      throw ImageSourceException(
        'Could not open the $what (${e.code}). Check that the app is allowed '
        'to use it in the phone settings.',
      );
    }
  }
}
