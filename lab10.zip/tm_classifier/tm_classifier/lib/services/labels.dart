/// "0 Mug\n1 Bottle\n" becomes ['Mug', 'Bottle'].
///
/// This lives in its own file, with no imports, so a plain unit test can use it
/// without pulling in tflite_flutter (which needs the native library).
///
/// `trim()` is what makes Windows line endings work: splitting on '\n' leaves a
/// '\r' at the end of each line, and trim() removes it. Only the leading index
/// is cut off, so a label with spaces in it ("2 Car keys") stays whole.
List<String> parseLabels(String raw) => [
      for (final line in raw.split('\n'))
        if (line.trim().isNotEmpty)
          line.trim().replaceFirst(RegExp(r'^\d+\s+'), ''),
    ];
