import 'dart:async';
import 'dart:io' show HandshakeException, SocketException;
import 'dart:typed_data';

import 'package:http/http.dart' as http;

/// A problem getting image bytes that can be shown to the user as it is.
class ImageSourceException implements Exception {
  const ImageSourceException(this.message);
  final String message;

  @override
  String toString() => message;
}

const maxDownloadBytes = 15 * 1024 * 1024;

/// T20: downloads one picture. Accepts the answer only when the status code is
/// 200 and the content-type starts with image/. Every other outcome becomes an
/// [ImageSourceException] with a message that says what went wrong.
///
/// [client] exists so tests can pass a fake one; the app leaves it out and
/// uses plain http.get.
Future<Uint8List> downloadImage(
  String address, {
  http.Client? client,
  Duration timeout = const Duration(seconds: 15),
}) async {
  final uri = Uri.tryParse(address.trim());
  if (uri == null ||
      !(uri.isScheme('http') || uri.isScheme('https')) ||
      uri.host.isEmpty) {
    throw const ImageSourceException(
      'That does not look like a web address. It should start with '
      'http:// or https://.',
    );
  }

  final http.Response response;
  try {
    response =
        await (client == null ? http.get(uri) : client.get(uri)).timeout(timeout);
  } on TimeoutException {
    throw const ImageSourceException(
      'The server took too long to answer. Try again, or use another address.',
    );
  } on SocketException {
    throw const ImageSourceException(_cannotConnect);
  } on HandshakeException {
    throw const ImageSourceException(
      'A secure connection to that server could not be set up.',
    );
  } on http.ClientException {
    throw const ImageSourceException(_cannotConnect);
  }

  if (response.statusCode != 200) {
    throw ImageSourceException(
      'The server answered with status ${response.statusCode} instead of 200, '
      'so there is no picture at that address.',
    );
  }

  final type = (response.headers['content-type'] ?? '').toLowerCase();
  if (!type.startsWith('image/')) {
    final shown = type.isEmpty ? 'something unknown' : type.split(';').first;
    throw ImageSourceException(
      'That address returns $shown, not a picture. Use a direct link to an '
      'image file, for example one ending in .jpg or .png.',
    );
  }

  final bytes = response.bodyBytes;
  if (bytes.isEmpty) {
    throw const ImageSourceException('The picture came back empty.');
  }
  if (bytes.length > maxDownloadBytes) {
    throw const ImageSourceException(
      'That picture is bigger than 15 MB. Pick a smaller one.',
    );
  }
  return bytes;
}

const _cannotConnect =
    'Could not reach that address. Check that your phone is online and that '
    'the address is spelled correctly.';
