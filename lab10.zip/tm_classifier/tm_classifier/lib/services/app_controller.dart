import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../models/history_entry.dart';
import 'classifier.dart';
import 'smoke_test.dart';

/// Owns the one Classifier and the session history (T11).
///
/// It is created once in main.dart and handed to the screens through their
/// constructors. No screen calls Classifier.load() itself.
class AppController extends ChangeNotifier {
  AppController({Future<Classifier> Function()? loader})
      : _loader = loader ?? Classifier.load;

  final Future<Classifier> Function() _loader;

  Classifier? _classifier;
  Object? _loadError;
  bool _loading = true;
  bool _disposed = false;
  final List<HistoryEntry> _history = [];

  Classifier? get classifier => _classifier;
  bool get isLoading => _loading;
  bool get isReady => _classifier != null;

  /// A readable description of what went wrong at start-up, or null.
  String? get loadError {
    final e = _loadError;
    if (e == null) return null;
    return e is ModelLoadException ? e.message : 'Unexpected problem: $e';
  }

  /// Newest first.
  List<HistoryEntry> get history => List.unmodifiable(_history);
  HistoryEntry? get latest => _history.isEmpty ? null : _history.first;

  /// Loads the model. Safe to call again for a retry.
  Future<void> init() async {
    _loading = true;
    _loadError = null;
    _notify();
    try {
      final loaded = await _loader();
      if (_disposed) {
        loaded.close();
        return;
      }
      _classifier = loaded;
      if (kDebugMode) await runSmokeTest(loaded);
    } catch (e) {
      _loadError = e;
    }
    _loading = false;
    _notify();
  }

  /// bytes -> classify -> history. The only place a picture is classified, so
  /// camera, gallery and download cannot drift apart.
  ///
  /// Throws [FormatException] if the bytes are not an image.
  Future<HistoryEntry> classify(Uint8List bytes, SourceKind source) async {
    final classifier = _classifier;
    if (classifier == null) {
      throw StateError('The model is not loaded yet.');
    }

    // classify() blocks the UI thread. Give Flutter a moment to paint the
    // "Classifying" overlay first, otherwise it never shows.
    await Future<void>.delayed(const Duration(milliseconds: 40));

    final stopwatch = Stopwatch()..start();
    final predictions = classifier.classify(bytes);
    stopwatch.stop();
    debugPrint('[classify] ${source.label}: ${stopwatch.elapsedMilliseconds} ms');

    final entry = HistoryEntry(
      bytes: bytes,
      predictions: predictions,
      source: source,
      inferenceMs: stopwatch.elapsedMilliseconds,
      time: DateTime.now(),
    );
    _history.insert(0, entry);
    _notify();
    return entry;
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    if (_disposed) return; // the app may reach this twice on shutdown
    _disposed = true;
    _classifier?.close();
    super.dispose();
  }
}
