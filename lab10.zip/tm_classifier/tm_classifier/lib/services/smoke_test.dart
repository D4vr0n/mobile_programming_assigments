import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'classifier.dart';

/// T10: classify assets/model/sample.jpg and print every label.
///
/// Check three things in the console:
///  1. there are as many lines as classes,
///  2. the right label is on top,
///  3. the confidences add up to 1.0 (within 0.01).
///
/// Only runs in debug mode. If sample.jpg is not there it just says so.
Future<void> runSmokeTest(Classifier classifier) async {
  const samplePath = 'assets/model/sample.jpg';
  try {
    final data = await rootBundle.load(samplePath);
    final results = classifier.classify(data.buffer.asUint8List());

    var sum = 0.0;
    for (final p in results) {
      sum += p.confidence;
      debugPrint('[smoke] ${p.label}: ${formatPercent(p.confidence)}');
    }
    final sumOk = (sum - 1).abs() <= 0.01;
    debugPrint(
      '[smoke] ${results.length} labels (model has ${classifier.labels.length} classes), '
      'top = ${results.first.label}, sum = ${sum.toStringAsFixed(4)} '
      '${sumOk ? "OK" : "NOT 1.0 - look at Part 3"}',
    );
  } catch (e) {
    debugPrint('[smoke] skipped: $e');
  }
}
