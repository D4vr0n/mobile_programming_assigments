import 'package:flutter/material.dart';

import '../models/history_entry.dart';
import '../services/classifier.dart';
import '../theme/app_theme.dart';

/// Thumbnail, top label, its percentage and the source. Used by History and
/// for the "latest result" card on Home.
class EntryTile extends StatelessWidget {
  const EntryTile({super.key, required this.entry, required this.onTap});

  final HistoryEntry entry;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.s + AppSpacing.xs),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.small),
                child: Image.memory(
                  entry.bytes,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  cacheWidth: 180, // decode small, the list may get long
                  errorBuilder: (context, error, stack) => Container(
                    width: 60,
                    height: 60,
                    color: scheme.surfaceContainerHighest,
                    child: const Icon(Icons.broken_image_outlined),
                  ),
                ),
              ),
              const SizedBox(width: AppSpacing.m),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.top.label,
                      style: theme.textTheme.titleMedium,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      '${formatPercent(entry.top.confidence)} · '
                      '${entry.source.label} · '
                      '${TimeOfDay.fromDateTime(entry.time).format(context)}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: scheme.onSurfaceVariant,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppSpacing.s),
              Icon(entry.source.icon, color: scheme.primary),
            ],
          ),
        ),
      ),
    );
  }
}
