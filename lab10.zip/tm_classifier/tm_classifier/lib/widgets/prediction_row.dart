import 'package:flutter/material.dart';

import '../services/classifier.dart';
import '../theme/app_theme.dart';

/// One label, a bar and the percentage. The top row is emphasised.
class PredictionRow extends StatelessWidget {
  const PredictionRow({
    super.key,
    required this.prediction,
    this.highlighted = false,
  });

  final Prediction prediction;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final labelStyle = highlighted
        ? theme.textTheme.titleMedium
        : theme.textTheme.bodyLarge;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.m,
        vertical: AppSpacing.s + AppSpacing.xs,
      ),
      decoration: BoxDecoration(
        color: highlighted ? scheme.primaryContainer : null,
        borderRadius: BorderRadius.circular(AppRadius.small),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              prediction.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: labelStyle,
            ),
          ),
          const SizedBox(width: AppSpacing.s),
          Expanded(
            flex: 4,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.small),
              child: LinearProgressIndicator(
                value: prediction.confidence.clamp(0.0, 1.0).toDouble(),
                minHeight: 10,
                color: highlighted ? scheme.primary : scheme.outline,
                backgroundColor: highlighted
                    ? scheme.surface
                    : scheme.surfaceContainerHighest,
              ),
            ),
          ),
          const SizedBox(width: AppSpacing.s),
          SizedBox(
            width: 76,
            child: Text(
              formatPercent(prediction.confidence),
              textAlign: TextAlign.end,
              maxLines: 1,
              style: labelStyle,
            ),
          ),
        ],
      ),
    );
  }
}
