import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Dims the screen, blocks taps and shows a spinner with a short message.
/// Used while downloading and while classifying.
class BusyOverlay extends StatelessWidget {
  const BusyOverlay({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Positioned.fill(
      child: Stack(
        children: [
          ModalBarrier(
            dismissible: false,
            color: theme.colorScheme.scrim.withValues(alpha: 0.4),
          ),
          Center(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(AppSpacing.l),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      width: 28,
                      height: 28,
                      child: CircularProgressIndicator(strokeWidth: 3),
                    ),
                    const SizedBox(width: AppSpacing.m),
                    Text(message, style: theme.textTheme.titleMedium),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
