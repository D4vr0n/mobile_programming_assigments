# ThingSpotter (tm_classifier)

Flutter app that runs a Teachable Machine image model (TensorFlow Lite) fully offline. It classifies pictures from the camera, the gallery or a downloaded image and shows a percentage for every label. See `NOTES.md` for the lab write-up.

Needs Flutter 3.27 or newer (it uses `CardThemeData`, `withValues` and `PopScope.onPopInvokedWithResult`).

## Setup

```bash
flutter create tm_classifier --empty      # creates android/, ios/ etc.
# copy lib/, test/, assets/, tools/, pubspec.yaml, NOTES.md, README.md over it
cd tm_classifier
python3 tools/patch_platforms.py          # camera/photo strings (iOS) + INTERNET (Android)
# put model_unquant.tflite, labels.txt (and sample.jpg) into assets/model/
# delete assets/model/README.txt
flutter pub get
dart fix --apply                          # only if analyze shows const hints
flutter analyze
flutter test
flutter run
```

If your generated `pubspec.yaml` has a different `environment: sdk:` line, keep yours.
If Gradle complains about `minSdkVersion`, raise `minSdk` in `android/app/build.gradle.kts` to the number it names.

## What only you can add

- [ ] `assets/model/model_unquant.tflite` and `labels.txt` from your own Teachable Machine project (6+ classes)
- [ ] `assets/model/sample.jpg` for the smoke test (T10)
- [ ] `docs/preview.png`, `docs/design-1.png`, `docs/design-2.png`
- [ ] Figma design credit in `lib/theme/design_credit.dart` and in `NOTES.md` (and copy its colours/font into `lib/theme/app_theme.dart`)
- [ ] Every `[[FILL IN ...]]` in `NOTES.md` (class list, evaluation table, timings, partner name)
- [ ] Screen recording under 60 s: camera, gallery, download, then History

## Tags

One commit and tag per part:

```bash
git tag p1-model        # model files, docs/preview.png, class list
git tag p2-setup        # pubspec.yaml, platform settings
git tag p3-classifier   # lib/services/*, tests
git tag p4-screens      # lib/theme, lib/screens, lib/widgets
git tag p5-sources      # sources, evaluation table
git push --tags
```

## Where things are

| Path | What |
|------|------|
| `lib/services/classifier.dart` | loads the model, pre-processes, returns sorted predictions |
| `lib/services/labels.dart` | `parseLabels`, pure Dart so it can be unit-tested |
| `lib/services/app_controller.dart` | one classifier, history, the single bytes→classify→history path |
| `lib/services/image_sources.dart`, `downloader.dart` | camera, gallery, URL |
| `lib/theme/` | the only place with colours, font sizes, radius, spacing, credit |
| `lib/screens/` | Welcome, Home, Result, History, Model, plus the bottom-nav shell |
| `test/` | `parseLabels` tests and download tests |
